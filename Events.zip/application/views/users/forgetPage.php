<div class="container"> 
<div id="forgetbox" style="margin-top:95px;" class="mainbox col-md-4 col-md-offset-4 col-sm-8 col-sm-offset-2">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="panel-title">Forgot password?</div>
                            <div style="float:right; font-size: 85%; position: relative; top:-19px"><a id="signinlink" href="<?php echo base_url()?>index.php/user/do_login" style="color:#fff">Return to Sign In</a></div>
                        </div>  
                        <div class="panel-body" >
						<p>Enter your email address and we'll send you a link to reset your password.</p>
                            <form id="forgetform" class="form-horizontal" role="form">
                                
                                <div id="forgetalert" style="display:none" class="alert alert-danger">
                                    <p>Error:</p>
                                    <span></span>
                                </div>
                                 
                                <div class="form-group">
                                    <div class="col-md-12 col-pad">
                                        <label for="email">Email Id</label>
										<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Your Email" name="email">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <!-- Button -->                                        
                                    <div class="col-md-12 col-pad">
                                        <button id="btn-restup" type="submit" class="btn-new btn-info" onclick="sendForgetmail()" name="actionForget" value="submitForgetPass"><i class="icon-hand-right"></i> &nbsp Reset Password</button>
                                    </div>
                                </div>
                            </form>
                         </div>
                    </div>
         </div> 
		 
    </div>
    <script type="text/javascript">
        function sendForgetmail()
        {   
            $('form#forgetform').submit(function(e) {

                var form = $(this);
                var actionForget = $('#btn-restup').val();
                console.log(actionForget);
                e.preventDefault();

                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url()?>index.php/user/sendforgetmail",
                    data: form.serialize() + "&actionForget=" +actionForget, // <--- THIS IS THE CHANGE
                    dataType: "html",
                    success: function(data){
                        $('#forgetbox').removeClass('mainbox col-md-4 col-md-offset-4 col-sm-8 col-sm-offset-2')
                        $('#forgetbox').html(data);
                        
                    },
                    error: function() { alert("Error posting feed."); }
               });

            });
        }
    </script>