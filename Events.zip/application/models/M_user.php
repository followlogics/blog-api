<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_user extends CI_Model {

    public function register($val) {

        $num = $this->db->insert('users', $val);

        if ($num) {
            return true;
        } else {
            return false;
        }
    }

    public function loginsucess($para1 = '', $para2 = '') {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('email', $para1);
        $this->db->where('password', MD5($para2));
        $this->db->where('status', 'ok');
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {   //echo "fdshgfhgds fdsgfh dshf dfghjd f ";
            $userinfo = $query->result_array();
            $this->session->set_userdata('user_id', $userinfo[0]['user_id']);
            $this->session->set_userdata('fname', $userinfo[0]['first_name']);
            $this->session->set_userdata('lname', $userinfo[0]['last_name']);
            $this->session->set_userdata('emailid', $userinfo[0]['email']);
            $this->session->set_userdata('frntuser', 'yes');
            $this->session->set_userdata('userrole', $userinfo[0]['user_role']);
            if ($this->input->post('remember')) {
                $login_name = array(
                    'name' => 'login_name',
                    'value' => $para1,
                    'expire' => time() + 365 * 24 * 60 * 5,
                    'path' => '/',
                    'prefix' => 'lg_',
                );
                $login_password = array(
                    'name' => 'login_password',
                    'value' => $para2,
                    'expire' => time() + 365 * 24 * 60 * 5,
                    'path' => '/',
                    'prefix' => 'lg_',
                );
                //echo "test";
                set_cookie($login_name);
                set_cookie($login_password);
            }

            return true;
        } else {

            return false;
        }
    }

    public function get_buyerinfo() {
        $userid = $this->session->userdata('user_id');
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('user_id', $userid);
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function get_promoterinfo() {
        $userid = $this->session->userdata('user_id');
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('user_id', $userid);
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function edit_promoterinfo($data1 = '', $data2 = '') {
        //print_r($data1);die;

        $this->db->where('user_id', $data2);

        if ($this->db->update('users', $data1)) {
            return true;
        }
    }

    public function edit_buyerinfo($data1 = '', $data2 = '') {
        //print_r($data1);die;

        $this->db->where('user_id', $data2);

        if ($this->db->update('users', $data1)) {
            return true;
        }
    }

    public function confirmchangePassword($data1 = '', $data2) {
        $data = array(
            'password' => MD5($data1)
        );
        $this->db->where('email', $data2);

        if ($this->db->update('users', $data)) {
            return true;
        }
    }

}
