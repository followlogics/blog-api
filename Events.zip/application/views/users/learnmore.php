<div class="container-fluid header-1">
<div class="header-content">
<h1>Learn More</h1>
<h3><a href="index.html">Home</a> > Learn More</h3>
</div>
</div>
	
	<div class="container space-top border-rj">
	<div class="row">
    <div class="col-md-10 col-md-offset-1">
	<p><b>CodTicket ™</b>  is a ticketing company that aims to securely produce and validate tickets for sports, recreational or other activities requiring authentication at the entrance of the public. </p>	
	<p>The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.</p>	
	<hr>
	<h3>Guidelines for image files</h3>
	<p><b>CodTicket ™</b>  is a ticketing company that aims to securely produce and validate tickets for sports, recreational or other activities requiring authentication at the entrance of the public. </p>	
	<p>The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.</p>	
	
	<hr>
	<h3>Where to add logos and other images</h3>
	<p><b>CodTicket ™</b>  is a ticketing company that aims to securely produce and validate tickets for sports, recreational or other activities requiring authentication at the entrance of the public. </p>	
	<p>The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.</p>	
	</div>
    </div>	
	</div>