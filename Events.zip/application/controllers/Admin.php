<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('M_admin');
    }

    public function index() {
        //$this->load->view('admin/header');
        $this->load->view('admin/signin');
        //$this->load->view('admin/footer');
    }

    public function do_signin() {
        if ($this->input->post('actionlog') == 'submit') {

            $username = $this->input->post('email');
            $password = $this->input->post('password');

            //$loginSucess = $this->m_admin->loginsucess($username,$password);
            $this->db->select('*');
            $this->db->from('users');
            $this->db->where('email', $username);
            $this->db->where('user_role', 'admin');
            $this->db->where('password', MD5($password));
            $query = $this->db->get();
            if ($query->num_rows() == 1) {
                $userinfo = $query->result_array();
                $this->session->set_userdata('user_id', $userinfo[0]['user_id']);
                $this->session->set_userdata('fname', $userinfo[0]['first_name']);
                $this->session->set_userdata('lname', $userinfo[0]['last_name']);
                $this->session->set_userdata('emailid', $userinfo[0]['email']);
                $this->session->set_userdata('frntuser', 'yes');
                $this->session->set_userdata('userrole', $userinfo[0]['user_role']);
                redirect('admin/dashboard');
            } else {

                $this->session->set_flashdata('item', array('message' => 'Your User name and Password do not match', 'class' => 'errormsg'));
                redirect('admin/index');
            }
        }
    }

    public function logout() {
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('fname');
        $this->session->unset_userdata('lname');
        $this->session->unset_userdata('emailid');
        $this->session->unset_userdata('frntuser');
        $this->session->unset_userdata('userrole');

        redirect('admin/index');
    }

    public function dashboard() {
        $this->load->view('admin/header');
        $this->load->view('admin/dashboard');
        $this->load->view('admin/footer');
    }

    public function promoters() {

        $this->load->view('admin/header');
        $this->load->view('admin/promoter');
        $this->load->view('admin/footer');
    }

    public function buyers() {
        $this->load->view('admin/header');
        $this->load->view('admin/buyer');
        $this->load->view('admin/footer');
    }

    public function manageEvents() {
        $this->load->view('admin/header');
        $this->load->view('admin/manage_event');
        $this->load->view('admin/footer');
    }

    public function printTicket() {
        $this->load->view('admin/header');
        $this->load->view('admin/print_ticket');
        $this->load->view('admin/footer');
    }

    public function Generateticket() {
        $this->load->view('admin/header');
        $this->load->view('admin/generate_ticket');
        $this->load->view('admin/footer');
    }

    public function adminProfile() {
        $userid = $this->session->userdata('user_id');
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('user_id', $userid);
        $query = $this->db->get();
        $result = $query->result_array();
        $data['proter'] = $result;
        $this->load->view('admin/header');
        $this->load->view('admin/myprofile', $data);
        $this->load->view('admin/footer');
    }

    public function editProfile() {
        $this->load->view('admin/header');
        $this->load->view('admin/profile_edit');
        $this->load->view('admin/footer');
    }

    public function adminprofileEdit() {   //die('ajay');
        if ($this->input->post('editprofil') == 'submit') {

            $userid = $this->session->userdata('user_id');

            $data['first_name'] = $this->input->post('firstname');

            $data['last_name'] = $this->input->post('lastname');

            $data['phone_number'] = $this->input->post('phonenumber');

            $data['email'] = $this->input->post('email');

            $data['gender'] = $this->input->post('gender');

            $data['home_address'] = $this->input->post('homeadd');

            $data['user_role'] = $this->input->post('userrole');

            $this->db->where('user_id', $userid);

            if ($this->db->update('users', $data)) {
                $this->session->set_flashdata('message', 'Your profile has been successfully update');
                redirect('admin/adminProfile');
            } else {

                $this->session->set_flashdata('message', 'Your profile has been not update plz check form');
                redirect('admin/editProfile');
            }
        }
    }

    public function changePassword() {
        $this->load->view('admin/header');
        $this->load->view('admin/change_password');
        $this->load->view('admin/footer');
    }

    public function PromoterView() {
        $this->load->view('admin/header');
        $this->load->view('admin/promoter_view');
        $this->load->view('admin/footer');
    }

    public function PromoterEdit() {
        $this->load->view('admin/header');
        $this->load->view('admin/promoter_edit');
        $this->load->view('admin/footer');
    }

    public function buyerView() {
        $this->load->view('admin/header');
        $this->load->view('admin/buyer_view');
        $this->load->view('admin/footer');
    }

    public function buyerEdit() {
        $this->load->view('admin/header');
        $this->load->view('admin/buyer_edit');
        $this->load->view('admin/footer');
    }

    public function eventView() {
        $this->load->view('admin/header');
        $this->load->view('admin/event_view');
        $this->load->view('admin/footer');
    }

    public function eventEdit() {
        $this->load->view('admin/header');
        $this->load->view('admin/event_edit');
        $this->load->view('admin/footer');
    }

    public function printTicketView() {
        $this->load->view('admin/header');
        $this->load->view('admin/print_ticket_view');
        $this->load->view('admin/footer');
    }

    public function printTicketEdit() {
        $this->load->view('admin/header');
        $this->load->view('admin/print_ticket_edit');
        $this->load->view('admin/footer');
    }

    public function buyerdelet() {
        $buyer_id = $this->uri->segment(3, 0);
        $this->db->where('user_id', $buyer_id);
        $this->db->delete('users');
        $this->session->set_flashdata('message', 'Record has been deleted successfully');
        redirect('admin/buyers');
    }

    public function promoterdelet() {
        $buyer_id = $this->uri->segment(3, 0);
        $this->db->where('user_id', $buyer_id);
        $this->db->delete('users');
        $this->session->set_flashdata('message', 'Record has been deleted successfully');
        redirect('admin/promoters');
    }

    public function addpromoters() {

        $this->load->view('admin/header');
        $this->load->view('admin/add_promoter');
        $this->load->view('admin/footer');
    }

    public function addbuyers() {
        $this->load->view('admin/header');
        $this->load->view('admin/add_buyer');
        $this->load->view('admin/footer');
    }

    public function do_promoters() {
        if ($this->input->post('action') == 'submit') {

            $data['first_name'] = $this->input->post('firstname');

            $data['last_name'] = $this->input->post('lastname');

            $data['phone_number'] = $this->input->post('phonenumber');

            $data['email'] = $this->input->post('email');

            $data['office_address'] = $this->input->post('office_address');

            $data['home_address'] = $this->input->post('home_address');

            $data['gender'] = $this->input->post('gender');

            $data['user_role'] = 'promoter';

            $data['status'] = 'ok';

            if ($this->db->insert('users', $data)) {
                $this->session->set_flashdata('message', 'Promter added successfully');

                redirect('admin/promoters');
            }
        } else {

            $this->session->set_flashdata('message', 'Promoter not add plz try again!');
            redirect('admin/addpromoters');
        }
    }

    public function do_buyers_add() {
        if ($this->input->post('action') == 'submit') {

            $data['first_name'] = $this->input->post('firstname');

            $data['last_name'] = $this->input->post('lastname');

            $data['phone_number'] = $this->input->post('phonenumber');

            $data['email'] = $this->input->post('email');

            $data['office_address'] = $this->input->post('office_address');

            $data['home_address'] = $this->input->post('home_address');

            $data['gender'] = $this->input->post('gender');

            $data['user_role'] = 'buyer';

            $data['status'] = 'ok';

            if ($this->db->insert('users', $data)) {
                $this->session->set_flashdata('message', 'buyer added successfully');

                redirect('admin/buyers');
            } else {

                $this->session->set_flashdata('message', 'buyer not add plz try again!');
                redirect('admin/addbuyers');
            }
        }
    }

    public function promotereditProfile() {
        //print_r($_POST);die;
        if ($this->input->post('editbyr') == 'submit') {

            $userid = $this->input->post('form_user');

            $data['first_name'] = $this->input->post('firstname');

            $data['last_name'] = $this->input->post('lastname');

            $data['phone_number'] = $this->input->post('phonenumber');

            $data['email'] = $this->input->post('email');

            $data['home_address'] = $this->input->post('home_address');

            $data['office_address'] = $this->input->post('office_address');

            $data['date_of_birth'] = $this->input->post('dob');

            $this->db->where('user_id', $userid);

            if ($this->db->update('users', $data)) {
                $this->session->set_flashdata('message', 'Buyer profile has been successfully update');
                redirect('admin/buyers');
            } else {

                $this->session->set_flashdata('message', 'Buyer profile has been not update plz check form');
                redirect('admin/buyers');
            }
        }
    }

    public function buyereditProfile() {
        //print_r($_POST);die;
        if ($this->input->post('editaction') == 'submit') {

            $userid = $this->input->post('form_user');

            $data['first_name'] = $this->input->post('firstname');

            $data['last_name'] = $this->input->post('lastname');

            $data['phone_number'] = $this->input->post('phonenumber');

            $data['email'] = $this->input->post('email');

            $data['home_address'] = $this->input->post('home_address');

            $data['office_address'] = $this->input->post('office_address');

            $data['date_of_birth'] = $this->input->post('dob');

            $this->db->where('user_id', $userid);

            if ($this->db->update('users', $data)) {
                $this->session->set_flashdata('message', 'Promoter profile has been successfully update');
                redirect('admin/promoters');
            } else {

                $this->session->set_flashdata('message', 'Promoter profile has been not update plz check form');
                redirect('admin/promoters');
            }
        }
    }

}
