	<footer>
	<div class="panel-footer-main">
	<div class="container">
	<div class="row">
    <div class="col-md-3">
	<h2>Contact Us</h2>
	<p><span><i class="fa fa-phone" aria-hidden="true"></i><span>  +15145713796 / +15146013882</p>
	<p><span><i class="fa fa-envelope" aria-hidden="true"></i><span>  contact@codticket.com</p>
	</div>
    
	<div class="col-md-3">
	<h2>Information</h2>
	<ul class="list-unstyled">
	<li><a href="<?php echo base_url();?>">Home</a></li>
	<li><a href="<?php echo base_url()?>index.php/user/aboutPage">Who we are</a></li>
	<li><a href="<?php echo base_url()?>index.php/user/ourSolutions">Our Solution</a></li>
	<li><a href="<?php echo base_url()?>index.php/user/contactus">Contact Us</a></li>
	</ul>
	</div>
	
	<div class="col-md-3">
	<h2>Extra Liks</h2>
	<ul class="list-unstyled">
	<li><a href="<?php echo base_url()?>index.php/user/discoveryEvent">Discovery Event</a></li>
	<?php if($this->session->userdata('userrole')=='promoter'|| $this->session->userdata('frntuser')==''){?>
	<li><a href="<?php echo base_url()?>index.php/user/eventcreate"  <?php echo $this->session->userdata('frntuser')=='' ? "id=footersignupform" : " "; ?>>Create Event</a></li>
	<?php } ?>
	<li><a href="<?php echo base_url()?>index.php/user/faq">FAQ</a></li>
	<?php if($this->session->userdata('frntuser')==''){?>
	<li><a href="<?php echo base_url()?>index.php/user/do_login">Sign In</a></li>
	<?php } ?>
	</ul>
	</div>
	
    <div class="col-md-3">
	<h2>NewsLetters</h2>
	<form>
    <div class="form-group">
    <label for="exampleInputEmail1">Get the new update via email...</label>
    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email Address" style="color: #fff;"/>
    </div>
    <button type="submit" class="btn btn-outline-primary-2">Subscribe</button>
    </form>
	</div>
    </div>
	</div>
	</div>
	
	<div class="panel-footer-copyright">
	<div class="container">
	<div class="row">
	<div class="col-md-6">
	<p>© 2017 <b>CodTicket</b> &nbsp;  | &nbsp;  All Rights Reserved. &nbsp; &nbsp;  Design By <b>Digital Brain Media</b></p>
	</div>
	<div class="col-md-6">
	<p style="margin: 0px;float: right;">
	<span><a href="#"><i class="fa fa-facebook-square" aria-hidden="true"></i></a><span>
	<span><a href="#"><i class="fa fa-twitter-square" aria-hidden="true"></i></a><span>
	<span><a href="#"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a><span>
	<span><a href="#"><i class="fa fa-youtube-square" aria-hidden="true"></i></a><span>
	<span><a href="#"><i class="fa fa-rss-square" aria-hidden="true"></i></a><span><p>
	</div>
	</div>
	</div>
	</div>
	</footer>
    
  </body>
</html>
<script type="text/javascript">
	$(document).ready(function(){
       $('#footersignupform').click(function(){
       	 $("#footersignupform").removeAttr("href").css("cursor","pointer");
         $('#loginmodel').modal('show');
       });
	});
</script>