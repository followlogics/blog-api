<div class="container-fluid header-1">
<div class="header-content">
<h1>Buyer Profile</h1>
<h3><a href="index.html">Home</a> > Buyer Profile</h3>
</div>
</div>
	<?php foreach ($proter as $proterdata){

   //print_r($proterdata);
} ?>
	<div class="container space-top border-rj">
	<div class="row">
    <div  class="col-sm-12">
        <div class="col-md-3"> <!-- required for floating -->
          <!-- Nav tabs -->
          <ul class="nav nav-tabs tabs-left">
            <li class="active"><a href="#personal" data-toggle="tab">Personal Information</a></li>
            <li><a href="#billing" data-toggle="tab">Billing information</a></li>
            <li><a href="#electronic" data-toggle="tab">Ticket Transaction history</a></li>
            <li><a href="#event" data-toggle="tab">Event Detail</a></li>
			<li><a href="#delete" data-toggle="tab">Account deletion</a></li>
          </ul>
        </div>

        <div class="col-md-9">
          <!-- Tab panes -->
          <div class="tab-content">
            <div class="tab-pane active" id="personal">
			<div class="rjheading">
			<h4>Personal information</h4>
			</div>
			<!-- <form class="form-horizontal" role="form"> -->
			<?php 
                                $attributes = array('class' => 'form-horizontal');
                                echo form_open('user/buyerProfile/update', $attributes);
                            ?>
                                
                                <div class="form-group">
                                    <div class="col-md-2 col-pad">
										<label for="type">Prefix</label>
                                        <select class="form-control" name="name_pre">
											<option value="" selected="selected">Select</option>
                                            <?php 
											$sqlquery=$this->db->query('select * from name_prefix');
											$sqlquery1=$sqlquery->result_array();
											foreach($sqlquery1 as $row){
												if($proterdata->name_prefix==$row['title']){
													$selected="selected='selected'";
												}else{
													$selected='';
												}
												echo "<option ".$selected." value='".$row['title']."'>".$row['title']."</option>";
											}
										?>
										</select>
                                    </div>
									<div class="col-md-5 col-pad">
										<label for="firstname">First Name</label>
                                        <input type="text" class="form-control" name="firstname" placeholder="First Name" value="<?php echo $proterdata->first_name ?>">
                                    </div>
									<div class="col-md-5 col-pad">
										<label for="lastname">Last Name</label>
                                        <input type="text" class="form-control" name="lastname" placeholder="Last Name" value="<?php echo $proterdata->last_name ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-6 col-pad">
										<label for="phonenumber">Phone Number</label>
                                        <input type="text" name="phonenumber" class="form-control" name="phonenumber" placeholder="Phone Number" value="<?php echo $proterdata->phone_number ?>">
                                    </div>
									<div class="col-md-6 col-pad">
										<label for="email">Email Address</label>
                                        <input type="text" name="email" class="form-control" name="email" placeholder="Email Address" value="<?php echo $proterdata->email ?>">
                                    </div>
                                </div>
								 
                                <div class="form-group">
                                    <div class="col-md-6 col-pad">
										<label for="address">Home Address</label>
                                        <textarea type="message" class="form-control" rows="4" placeholder="Home Address" name="home_add"><?php echo $proterdata->home_address ?></textarea>
                                    </div>
									<div class="col-md-6 col-pad">
										<label for="address">Office Address</label>
                                        <textarea type="message" class="form-control" rows="4" placeholder="Billing Address" name="office_add" ><?php echo $proterdata->office_address ?></textarea>
                                    </div>
                                </div>
                                  
                                <div class="form-group">
                                    <div class="col-md-6 col-pad">
										<label for="phone">Gender</label>
                                        <select class="form-control" name="gender">
											<option value="">Select Gender</option>
                                            <option value="Male" <?php if($proterdata->gender =="Male") echo 'selected="selected"'; ?>>Male</option>
                                            <option value="Female" <?php if($proterdata->gender =="Female") echo 'selected="selected"';?>>Female</option>
                                            <option value="Other" <?php if($proterdata->gender =="Other") echo 'selected="selected"';?>>Other</option>
										</select>
                                    </div>
									<div class="col-md-6 col-pad">
										<label for="phone">Date of Birth</label>
                                        <input type="text" class="form-control" id="datetimepicker2" placeholder="Phone Number" name="dob" value="<?php echo $proterdata->date_of_birth?>">
                                    </div>
                                </div>
								
								<!-- <div class="form-group">
									<div class="col-md-12 col-pad">
										<label for="exampleInputFile">Profile Image</label>
										<input type="file" id="file">
                                    </div>
								</div> -->
                                  
                                <div class="form-group">
                                    <!-- Button -->                                        
                                    <div class="col-md-12 col-pad">
									<button type="submit" class="btn btn-outline-primary-rj" name="action" value="submit">Save</button>  
                                    </div>
                                </div>
            </form>
			</div>
            <div class="tab-pane" id="billing">
			<div class="rjheading">
			<h4>Billing information</h4>
			</div>
			<!-- <form class="form-horizontal" role="form"> -->
			                <?php 
                                $attributes = array('class' => 'form-horizontal');
                                echo form_open('user/buyerbilling', $attributes);
                            ?>
                                
                                
                                <div class="form-group">
                                    <div class="col-md-6 col-pad">
										<label for="phonenumber">Phone Number</label>
                                        <input type="text" class="form-control" name="billing_phone" placeholder="Phone Number" value="<?php echo $proterdata->billing_phone?>">
                                    </div>
									<div class="col-md-6 col-pad">
										<label for="email">Bill to Email</label>
                                        <input type="text" class="form-control" name="billing_email" placeholder="Email Address" value="<?php echo $proterdata->billing_email?>">
                                    </div>
                                </div>
								
								 <div class="form-group">
                                    <div class="col-md-6 col-pad">
										<label for="address">Bank Name</label>
                                        <input type="text" class="form-control" name="bank_name" placeholder="Bank Name" value="<?php echo $proterdata->bank_name?>">
                                    </div>
									<div class="col-md-6 col-pad">
										<label for="address">Account Number</label>
                                        <input type="text" class="form-control" name="bank_account_number" placeholder="Account Number" value="<?php echo $proterdata->bank_account_number?>">
                                    </div>
                                </div>
								 
                                <div class="form-group">
                                    <div class="col-md-4 col-pad">
										<label for="address">Street 1</label>
                                        <input type="text" class="form-control" name="billing_street1" placeholder="Street 1" value="<?php echo $proterdata->billing_street1?>">
                                    </div>
									<div class="col-md-4 col-pad">
										<label for="address">Street 2</label>
                                        <input type="text" class="form-control" name="billing_street2" placeholder="Street 2" value="<?php echo $proterdata->billing_street2 ?>">
                                    </div>
                                    <div class="col-md-4 col-pad">
										<label for="address">Country</label>
										<select class="form-control" name="country" id="country">
											<option value="">Select Country</option>
											
										</select>
                                    </div>
									
                                </div>
								
								<div class="form-group">
                                    <div class="col-md-4 col-pad">
										<label for="address">State</label>
										<select class="form-control" name="state" id="state">
											<option value="">Select State</option>
											
										</select>
                                    </div>
                                    <div class="col-md-4 col-pad">
										<label for="address">City</label>
                                        <input type="text" class="form-control" name="billing_city" placeholder="City" value="<?php echo $proterdata->billing_city ?>">
                                    </div>
									
									<div class="col-md-4 col-pad">
										<label for="address">Postal Code</label>
                                        <input type="text" class="form-control" name="billing_postelcode" placeholder="Postal Code" value="<?php echo $proterdata->billing_postelcode ?>">
                                    </div>
                                </div>
                                  
                                <div class="form-group">
                                    <!-- Button -->                                        
                                    <div class="col-md-12 col-pad">
									<button type="submit" class="btn btn-outline-primary-rj" name="action2" value="submit">Save</button>  
                                    </div>
                                </div>
            </form>
			</div>
			
			
            <div class="tab-pane" id="electronic">
			<div class="rjheading">
			<h4>Ticket Transaction history</h4>
			</div>
	<table class="table table-striped rjtable">
    <thead>
      <tr>
	  <th>S. No.</th>
	  <th>Ticket Type</th>
	  <th>Price</th>
	  <th>Quantity</th>
	  <th>Total</th>
	  <th>View Invoice</th>
	  </tr>
    </thead>
    <tbody>
      <tr>
        <td>01</td>
        <td>General Ticket</td>
        <td>$100</td>
        <td>2</td>
        <td>$200</td>
		<td><button type="button" class="btn btn-info invoicebtn" onclick="invoicedetail();"> View Invoice</button> </td>
      </tr>
	  
	  <tr>
        <td>02</td>
        <td>VIP Ticket</td>
        <td>$150</td>
        <td>$1</td>
        <td>$150</td>
		<td><button type="button" class="btn btn-info invoicebtn" onclick="invoicedetail();"> View Invoice</button> </td>
      </tr>
    </tbody>
	</table>
			
			
			
			<div id="page-wrap-1" style="display:none;">

		<textarea id="header">INVOICE</textarea>
		
		<div id="identity">
		
            <textarea id="address">Chris Coyier
									123 Appleseed Street
									Appleville, WI 53719

									Phone: (555) 555-5555</textarea>

            <div id="logo">
              <img id="image" src="images/logo.png" style="width: 160px;" />
            </div>
		
		</div>
		
		<div style="clear:both"></div>
		
		<div id="customer">

            <textarea id="customer-title">CodTicket</textarea>

            <table id="meta">
                <tr>
                    <td class="meta-head">Invoice #</td>
                    <td><textarea>000001</textarea></td>
                </tr>
                <tr>

                    <td class="meta-head">Date</td>
                    <td><textarea id="date">December 15, 2016</textarea></td>
                </tr>
                <tr>
                    <td class="meta-head">Amount Due</td>
                    <td><div class="due">$100.00</div></td>
                </tr>

            </table>
		
		</div>
		
		<table id="items">
		
		  <tr>
		      <th>Ticket Name</th>
		      <th>Description</th>
			  <th>Ticket Type</th>
		      <th>Quantity</th>
		      <th>Price</th>
		  </tr>
		  
		  <tr class="item-row">
		      <td class="item-name"><div class="delete-wpr"><textarea>SPIRITUAL ADVENTURE 2017</textarea></div></td>
		      <td class="description"><textarea>We take care of creating and validating tickets on the day of the show.</textarea></td>
			  <td><textarea class="cost">General Ticket</textarea></td>
		      <td><textarea class="qty">1</textarea></td>
		      <td><span class="price">$50.00</span></td>
		  </tr>
		  
		  <tr>
		      <td colspan="2" class="blank"> </td>
		      <td colspan="2" class="total-line">Subtotal</td>
		      <td class="total-value"><div id="subtotal">$875.00</div></td>
		  </tr>
		  <tr>

		      <td colspan="2" class="blank"> </td>
		      <td colspan="2" class="total-line">Total</td>
		      <td class="total-value"><div id="total">$875.00</div></td>
		  </tr>
		  <tr>
		      <td colspan="2" class="blank"> </td>
		      <td colspan="2" class="total-line">Amount Paid</td>

		      <td class="total-value"><textarea id="paid">$0.00</textarea></td>
		  </tr>
		  <tr>
		      <td colspan="2" class="blank"> </td>
		      <td colspan="2" class="total-line balance">Balance Due</td>
		      <td class="total-value balance"><div class="due">$875.00</div></td>
		  </tr>
		
		</table>
		
		<div id="terms">
		  <h5>Terms</h5>
		  <textarea>NET 30 Days. Finance Charge of 1.5% will be made on unpaid balances after 30 days.</textarea>
		</div>
		
		<div class="col-md-12 col-pad" style="text-align:center;">
		<button type="button" class="btn btn-outline-primary-rj"> Print</button>  
                                    </div>
	
	</div>
			</div>
            <div class="tab-pane" id="event">
			<div class="rjheading">
			<h4>Event Detail</h4>
			</div>
	<table class="table table-striped rjtable">
    <thead>
      <tr>
	  <th>S. No.</th>
	  <th>Event Name</th>
	  <th>Date</th>
	  <th>Location</th>
	  <th>View Event</th>
	  </tr>
    </thead>
    <tbody>
      <tr>
        <td>01</td>
        <td>SPIRITUAL ADVENTURE 2017</td>
        <td>06-03-2017</td>
        <td>505 N Lincoln Ave, Chicago, IL 60653, USA</td>
		<td><a href="event-detail.html"><button type="button" class="btn btn-info invoicebtn"> View Event</button></a> </td>
      </tr>
	  
	  <tr>
        <td>02</td>
        <td>SPIRITUAL ADVENTURE</td>
        <td>01-03-2017</td>
        <td>Lincoln Ave, Chicago, IL 60653, USA</td>
		<td><a href="event-detail.html"><button type="button" class="btn btn-info invoicebtn"> View Event</button></a> </td>
      </tr>
    </tbody>
	</table>
	<!--<div class="row event-area">
    <div class="col-md-4">
	<img src="images/event-detail.jpg">
	<h3 class="img-caption">Arts and Entertainment</h3>
	</div>
    <div class="col-md-8">
	<div class="event-detial-profile">
	<h1>Spiritual adventure 2017 </h1>
	<p><span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span></p>
	</div>
	<div class="event-detial-block-profile">
	<p>We take care of creating and validating tickets on the day of the show. Our ticketing system is computerized, innovative and safe. We take care of creating and validating tickets on the day of the show. Our ticketing system is computerized, innovative and safe.</p>
	<p><span><i class="fa fa-map-marker" aria-hidden="true"></i><span> &nbsp;  505 N Lincoln Ave, Chicago, IL 60653, USA</p>
	</div>	
	<a href="event-detail.html"><button type="button" class="btn btn-outline-primary-5">View More</button></a>
	</div>
	</div>
	
	<div class="row event-area">
    <div class="col-md-4">
	<img src="images/event-detail.jpg">
	<h3 class="img-caption">Arts and Entertainment</h3>
	</div>
    <div class="col-md-8">
	<div class="event-detial-profile">
	<h1>Spiritual adventure 2017 </h1>
	<p><span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span></p>
	</div>
	<div class="event-detial-block-profile">
	<p>We take care of creating and validating tickets on the day of the show. Our ticketing system is computerized, innovative and safe. We take care of creating and validating tickets on the day of the show. Our ticketing system is computerized, innovative and safe.</p>
	<p><span><i class="fa fa-map-marker" aria-hidden="true"></i><span> &nbsp;  505 N Lincoln Ave, Chicago, IL 60653, USA</p>
	</div>	
	<a href="event-detail.html"><button type="button" class="btn btn-outline-primary-5">View More</button></a>
	</div>
	</div>-->
			</div>
			<div class="tab-pane deactiverj" id="delete">
			<div class="rjheading">
			<h4>Account Deletion</h4>
			</div>
			<h4>Deactivate Your Account</h4>
<form class="form-horizontal" role="form">
  <div class="col-md-4">
  <div class="form-group">
    <div>
      <input type="email" class="form-control" id="exampleInputAmount" placeholder="Enter Email Address..." style="border-radius: 0px;">
    </div>
  </div>
  </div>
  <div class="col-md-4">
  <button type="submit" class="btn btn-outline-primary-search">Request for Deactivate</button>
   </div>
</form>
			</div>
        </div> </div>

        <div class="clearfix"></div>

      </div>
    </div>	
	</div>

	<script language="javascript">
	populateCountries("country", "state"); // first parameter is id of country drop-down and second parameter is id of state drop-down
	populateCountries("country2");
	populateCountries("country2");
    </script>