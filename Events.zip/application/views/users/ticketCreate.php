<?php if ($this->uri->segment(3, 0) == '') {
    redirect('user/eventcreate');
} ?>
<div class="container-fluid header-1">
    <div class="header-content">
        <h1>Create Event</h1>
        <h3><a href="<?php echo base_url()?>">Home</a> > Create Event</h3>
    </div>
</div>

<div class="container space-top border-rj">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class=" create-event">
                <h1>1</h1><h2> &nbsp; &nbsp;  CREATE TICKET</h2>
            </div>
            <form>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-12 col-pad-2">
                            <div class="form-group">
                                <label for="eventtitle">PROMOTER NAME</label>
                                <input type="text" class="form-control" placeholder="Promoter Name">
                            </div>

                            <div class="form-group">
                                <label for="eventtitle">EVENT DATE TIME</label>
                                <input type="text" class="form-control" id="datetimepicker1" placeholder="Event Date and Time">
                            </div>

                            <p style="text-align:center;">What type of ticket would you like to start with?</p>


                            <p style="text-align:center;">
                                <button type="button" class="btn btn-outline-primary-rj" data-toggle="collapse" data-target="#collapsetwo"><i class="fa fa-plus-circle" aria-hidden="true"></i> General Ticket</button> &nbsp; &nbsp; 
                                <button type="button" class="btn btn-outline-primary-rj" data-toggle="collapse" data-target="#collapsethree"><i class="fa fa-plus-circle" aria-hidden="true"></i> VIP Ticket</button> &nbsp; &nbsp; 
                                <button type="button" class="btn btn-outline-primary-rj" data-toggle="collapse" data-target="#collapsefour"><i class="fa fa-plus-circle" aria-hidden="true"></i> Other Ticket</button></p>
                            <div id="collapsetwo" class="panel-collapse collapse">
                                <table class="table table-striped rjtable">
                                    <thead>
                                        <tr><th colspan="3" style="text-align: center;">GENERAL TICKET</th></tr>
                                    </thead>
                                    <thead>
                                        <tr>
                                            <th>Event Title</th>
                                            <th>Quantity Available</th>
                                            <th>Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><input type="text" class="form-control" id="text" placeholder="Event Title"></td>
                                            <td><input type="text" class="form-control" id="text" placeholder="Number of Tickets"></td>
                                            <td><input type="text" class="form-control" id="text" placeholder="Price"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div id="collapsethree" class="panel-collapse collapse">
                                <table class="table table-striped rjtable">
                                    <thead>
                                        <tr><th colspan="3" style="text-align: center;">VIP TICKET</th></tr>
                                    </thead>
                                    <thead>
                                        <tr>
                                            <th>Event Title</th>
                                            <th>Quantity Available</th>
                                            <th>Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><input type="text" class="form-control" id="text" placeholder="Event Title"></td>
                                            <td><input type="text" class="form-control" id="text" placeholder="Number of Tickets"></td>
                                            <td><input type="text" class="form-control" id="text" placeholder="Price"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div id="collapsefour" class="panel-collapse collapse">
                                <table class="table table-striped rjtable">
                                    <thead>
                                        <tr><th colspan="4" style="text-align: center;">OTHER TICKET</th></tr>
                                    </thead>
                                    <thead>
                                        <tr>
                                            <th>Ticket Type</th>
                                            <th>Event Title</th>
                                            <th>Quantity Available</th>
                                            <th>Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><input type="text" class="form-control" id="text" placeholder="Ticket Type"></td>
                                            <td><input type="text" class="form-control" id="text" placeholder="Event Title"></td>
                                            <td><input type="text" class="form-control" id="text" placeholder="Number of Tickets"></td>
                                            <td><input type="text" class="form-control" id="text" placeholder="Price"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div></div> 

                    <div class="form-group">
                        <label for="eventtitle">MODE OF TICKET</label>
                        <select class="form-control">
                            <option value="" selected="selected">Select Mode</option>
                            <option value="1">Presale Online</option>
                            <option value="2">Exclusive Sale Online</option>
                            <option value="2">Exclusive Offline Sale</option>
                            <option value="2">Concurrent Online and Offline</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="eventtitle">TYPE OF IMPRESSION</label>
                        <div class="radio">
                            <label>
                                <input type="radio" onclick="javascript:yesnoCheck();" name="yesno" id="yesCheck"> Color (Choose Color)
                            </label>
                        </div>  
                        <div id="ifYes" style="display:none;margin-left: 25px;">
                            <div class="radio">
                                <label>
                                    <input type="radio" name="optionsRadios" id="optionsRadios3" value="red"> Paper Color: Red
                                </label>
                            </div> 
                            <div class="radio">
                                <label>
                                    <input type="radio" name="optionsRadios" id="optionsRadios4" value="green"> Paper Color: Green
                                </label>
                            </div> 
                            <div class="radio">
                                <label>
                                    <input type="radio" name="optionsRadios" id="optionsRadios5" value="blue"> Paper Color: Blue
                                </label>
                            </div> 
                        </div>

                        <div class="radio">
                            <label>
                                <input type="radio" onclick="javascript:yesnoCheck();" name="yesno" id="noCheck"> Gray Scale (Paper Color: White)
                            </label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="eventtitle">NUMBER OF SECTIONS</label>
                        <input type="text" class="form-control" placeholder="Number of Sections">
                    </div>

                    <div class="form-group">
                        <label for="eventtitle">ROWS PER SECTION</label>
                        <input type="text" class="form-control" placeholder="Rows per Section">
                    </div>

                    <div class="form-group">
                        <label for="eventtitle">SEATS PER ROW</label>
                        <input type="text" class="form-control" placeholder="Seats per Row">
                    </div>
                    <div class="form-group">
                        <label for="eventtitle">TICKET SIZE</label>
                        <input type="text" class="form-control" placeholder="139.5 x 54mm ( Corresponds to 8 tickets on a page )" disabled>
                    </div>
                    <div class="form-group">
                        <label for="eventtitle">PACKAGING</label>
                        <input type="text" class="form-control" placeholder="Carnets of 25, 50, 100 tickets, free tickets">
                    </div>
                    <div class="form-group">
                        <label for="eventtitle">POSTER IMAGE OF TICKET</label>
                        <input type="file" id="file">
                    </div>
                    <div class="form-group">
                        <label for="eventtitle">PROMOTER LOGO</label>
                        <input type="file" id="file">
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog" style="    width: 1090px;">

                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Ticket Preview</h4>
                                </div>
                                <div class="modal-body">
                                    <section class="invoice rjticket" style="padding: 0px;background: #fff;">
                                        <!-- title row -->
                                        <div class="row print_ticket">
                                            <div class="col-xs-3" style="padding-bottom: 0px;padding-top: 0px;">
                                                <div style="border-right: 1px dotted;">
                                                    <p style="margin: 0;">Promoter</p>
                                                    <h4 style="font-weight: bold;margin: 5px 0;">Event Title</h4>
                                                    <p style="margin: 0;">Event Date and Hour</p>
                                                    <p style="margin: 0;">VIP</p>
                                                    <p style="margin: 0;">1</p>
                                                    <p style="margin: 0;">A</p>
                                                    <p style="margin: 0;">1</p>
                                                    <p style="margin: 0;">20 $ CAD</p>
                                                    <p style="margin: 3px 0px 10px;font-size: 19px;">Ticket Number (10020)</p>
                                                    <img src="<?php echo base_url() ?>assets/images/qrcode.png" style="width: 65px; margin-bottom: 10px;">
                                                    <p>www.codticket.com</p>
                                                </div>
                                            </div>
                                            <!-- /.col -->
                                            <div class="col-xs-3" style="padding-left: 0px;padding-bottom: 0px;padding-top: 0px;">
                                                <img src="<?php echo base_url() ?>assets/images/event-poster.jpg" style="width: 100%; margin-bottom: 10px;">
                                                <p style="text-align: center;margin: 0;">CONTACT</p>
                                                <p style="font-size: 12px;text-align: center;">www.siteeventmanage.com tel:9911229933</p>
                                            </div>
                                            <!-- /.col -->
                                            <div class="col-xs-6" style="padding-bottom: 0px;padding-top: 0px;">
                                                <div class="col-xs-8" style="padding-left: 0px;    padding-top: 0px;">
                                                    <p style="text-align:center;font-size: 16px;">Promoter Name</p>
                                                    <h4 style="text-align:center;font-size: 26px;font-weight: bold;margin: 10px 0 20px;">Event Title</h4>

                                                    <p style="text-align:center;font-size: 16px;">Event Address</p>
                                                    <h4 style="text-align:center;font-size: 22px;font-weight: bold;">Event Date and Hour</h4>
                                                </div>
                                                <div class="col-xs-4" style="padding-right: 0px;    padding-top: 0px;">
                                                    <img src="<?php echo base_url() ?>assets/images/event-logo.jpg" style="width: 100px; margin-bottom: 10px; float:right;">
                                                </div>
                                                <div class="col-xs-12" style="padding: 0px;">
                                                    <table class="table" style="font-size: 17px;">
                                                        <tr>
                                                            <td style="border: none;padding-left: 0px;">Ticket Type (VIP)</td>
                                                            <td style="border: none;">Section <b>1</b></td>
                                                            <td style="border: none;">Row <b>A</b></td>
                                                            <td style="border: none;">Seat <b>1</b></td>
                                                        </tr>
                                                    </table>
                                                    <table class="table" style="font-size: 17px;margin: 0px;">
                                                        <tr>
                                                            <td style="border: none;padding-left: 0px;">Price <b>20 $CAD</b></td>
                                                            <td style="border: none;"><b>Ticket Number (10020)</b></td>
                                                            <td rowspan="2" style="border: none;padding-right: 0px;text-align: right;">
                                                                <img src="<?php echo base_url() ?>assets/images/qrcode.png" style="width: 75px; margin-bottom: 10px;"></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="border: none;font-size: 13px;text-align: center;padding-left: 0px;">Issue Date : 11/03/2017</td>
                                                            <td style="border: none;font-size: 13px;text-align: center;">www.codticket.com</td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                            <!-- /.col -->
                                        </div>
                                    </section>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <p style="text-align:center;"><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Preview Ticket</button>
                    &nbsp; &nbsp;  <button type="button" class="btn btn-outline-primary-rj">Create Ticket</button> </p>
            </form>	
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#datetimepicker1').datetimepicker({
        format: 'Y-m-d H:i',
    });
    $('#datetimepicker2').datetimepicker({
        format: 'Y-m-d H:i',
    });

    function yesnoCheck() {
        if (document.getElementById('yesCheck').checked) {
            document.getElementById('ifYes').style.display = "block";
        } else
            document.getElementById('ifYes').style.display = "none";

    }

</script>