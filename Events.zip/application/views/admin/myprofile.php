<?php 
if($this->session->flashdata('message')!=null){  ?>
<script>
 var msg = "<?php echo $this->session->flashdata('message');?>";
toastr.success(msg);
</script>
<?php } ?>
<?php foreach ($proter as $proterdata){

   print_r($proterdata);
} ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>My Profile</h1>
      <ol class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">My profile</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url()?>assets/dist/img/user2-160x160.jpg" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo $proterdata['first_name'].' '.$proterdata['last_name']?></h3>

              <p class="text-muted text-center"><?php echo $proterdata['user_role']?></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Name</b> <a class="pull-right"><?php echo $proterdata['first_name'].' '.$proterdata['last_name']?></a>
                </li>
                <li class="list-group-item">
                  <b>Phone No.</b> <a class="pull-right"><?php echo $proterdata['phone_number']?></a>
                </li>
                <li class="list-group-item">
                  <b>Email</b> <a class="pull-right"><?php echo $proterdata['email']?></a>
                </li>
              </ul>

              <a href="<?php echo base_url()?>index.php/admin/editProfile" class="btn btn-primary btn-block"><b>Edit Profile</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          
        </div>
        <!-- /.col -->
        <div class="col-md-9">
		
		<!-- About Me Box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">About Me</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> Personal Information</strong>
				</br></br>
              <p class="text-muted"><b>Name : </b> <?php echo $proterdata['first_name'].' '.$proterdata['last_name']?></p>
			  <p class="text-muted"><b>Phone Number : </b><?php echo $proterdata['phone_number']?></p>
			  <p class="text-muted"><b>Email : </b><?php echo $proterdata['email']?></p>
			  <p class="text-muted"><b>Designation : </b> <?php echo $proterdata['user_role']?></p>

              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
					</br></br>
              <p class="text-muted">Malibu, California</p>

              <hr>
			  <a href="<?php echo base_url()?>index.php/admin/editProfile" class="btn btn-primary"><b>Edit Profile</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
		
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->