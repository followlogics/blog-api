<div class="container">    
        

        <div id="signupbox" style="margin-top:95px" class="mainbox col-md-4 col-md-offset-4 col-sm-8 col-sm-offset-2">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="panel-title">Sign Up</div>
                            <div style="float:right; font-size: 85%; position: relative; top:-19px"><a id="signinlink" href="<?php echo base_url()?>index.php/user/do_login"  style="color:#fff">Sign In</a></div>
                        </div>  
                        <div class="panel-body" >
                            <!-- <form id="signupform" class="form-horizontal" role="form"> -->
                            <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'signupform');
                                echo form_open('user/do_signup', $attributes);
                            ?>
                                
                                <div id="signupalert" style="display:none" class="alert alert-danger">
                                    <p>Error:</p>
                                    <span></span>
                                </div>
                                
								<div class="form-group">
                                    <div class="col-md-12 col-pad">
										<label for="type">Type of Users </label>
                                        <select class="form-control" name="userrole">
										<option value="promoter" selected="selected">Promoters</option>
										<option value="buyer">Buyers</option>
										</select>
                                    </div>
                                </div>
								
                                <div class="form-group">
                                    <div class="col-md-12 col-pad">
										<label for="firstname">First Name</label>
                                        <input type="text" class="form-control" name="firstname" placeholder="First Name" value="<?php echo set_value('firstname'); ?>">
                                        <?php echo form_error('firstname');?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12 col-pad">
										<label for="lastname">Last Name</label>
                                        <input type="text" class="form-control" name="lastname" placeholder="Last Name" value="<?php echo set_value('lastname'); ?>">
                                        <?php echo form_error('lastname');?>
                                    </div>
                                </div>
								 
                                <div class="form-group">
                                    <div class="col-md-12 col-pad">
										<label for="email">Email</label>
                                        <input type="text" class="form-control" name="email" placeholder="Email Address" value="<?php echo set_value('email'); ?>">
                                        <?php echo form_error('email');?>
                                    </div>
                                </div>
                                  
                                <div class="form-group">
                                    <div class="col-md-12 col-pad">
										<label for="phone">Phone No.</label>
                                        <input type="text" class="form-control" name="phone" placeholder="Phone Number" value="<?php echo set_value('phone'); ?>">
                                        <?php echo form_error('phone');?>
                                    </div>
                                </div>
    
                                <div class="form-group">
                                    <div class="col-md-12 col-pad">
										<label for="password">Password</label>
                                        <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                                        <?php echo form_error('password');?>
                                    </div>
                                </div>
								
								<div class="form-group">
                                    <div class="col-md-12 col-pad">
										<label for="confirmpasswd">Confirm Password</label>
                                        <input type="password" class="form-control" name="confirmpasswd" id="confirmpasswd" placeholder="Confirm Password">
                                        <?php echo form_error('confirmpasswd');?>
                                    </div>
                                </div>
								
								<!-- <div class="form-group">
									<div class="col-md-12 col-pad">
										<label for="exampleInputFile">Profile Image</label>
										<input type="file" id="file">
                                    </div>
								</div> -->
                                  
                                <div class="form-group">
                                    <!-- Button -->                                        
                                    <div class="col-md-12 col-pad">
                                        <button id="btn-signup" type="submit" class="btn-new btn-info" name="action" value="submit"><i class="icon-hand-right"></i> &nbsp Sign Up</button>
                                        <!-- <span style="margin-left:8px;">or</span> -->  
                                    </div>
                                </div>
                                
                                <!-- <div style="border-top: 1px solid #999; padding-top:20px"  class="form-group">
                                    
                                    <div class="col-md-12 col-pad">
                                        <button id="btn-fbsignup" type="button" class="btn-new btn-primary"><i class="icon-facebook"></i>   Sign Up with Facebook</button>
                                    </div>
                                </div> -->
                            </form>
                         </div>
                    </div>
         </div>
		 
    </div>

<script type="text/javascript">
        
        $(document).ready(function() {
            $("#signupform").removeAttr("novalidate");
            $("#signupform").validate({
               rules: {
                    firstname: "required",
                    lastname: "required",
                    email: {
                      required: true,
                      email: true
                    },
                    phone: "required",
                    password: "required",
                    confirmpasswd: {
                      equalTo: "#password",
                      required: true
                    }
                  },
                messages: {
                    firstname: "Please specify your first name",
                    lastname: "Please specify your last name",
                    email: {
                      required: "We need your email address to contact you",
                      email: "Your email address must be in the format of name@domain.com"
                    },
                    phone: "Please specify your phone number",
                    password: "Please enter your password",
                    confirmpasswd: {
                      required: "Please specify your confirm password",
                      equalTo: "Your confirm password not match"
                    }
                }

             });
        });

</script>