<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>View Print Ticket Order</h1>
      <ol class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">View Print Ticket Order</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
	  <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="img-responsive" src="dist/img/event.jpg" alt="User profile picture">

              <h3 class="profile-username text-center">Spiritual</h3>

              <p class="text-muted text-center"><b>Mode of Ticket : </b> Offline</p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Ticket Number</b> <a class="pull-right">10020</a>
                </li>
                <li class="list-group-item">
                  <b>No. of Ticket</b> <a class="pull-right">200</a>
                </li>
                <li class="list-group-item">
                  <b>Price per Ticket</b> <a class="pull-right">$100</a>
                </li>
              </ul>

              <a href="print-ticket.html" class="btn btn-primary btn-block"><b>Back</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
		
        <div class="col-md-9">
		
		<!-- About Me Box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">View Print Ticket Order</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i>Print Ticket Order Detail</strong>
				</br></br>
              <p class="text-muted"><b>Promoter Name : </b> Chester Bennington</p>
			  <p class="text-muted"><b>Event Title : </b> Spiritual Adventure 2017</p>
			  <p class="text-muted"><b>Ticket Type : </b> General Ticket</p>
			  <p class="text-muted"><b>No. of Ticket : </b> 200</p>
			  <p class="text-muted"><b>Price per Ticket : </b> $100</p>
			  <p class="text-muted"><b>Mode of Ticket : </b> Offline</p>
			  <p class="text-muted"><b>Type of Impression : </b> Gray Scale (Paper Color: White)</p>
			  <p class="text-muted"><b>Ticket Size : </b> 139.5 x 54mm ( Corresponds to 8 tickets on a page )</p>
			  <p class="text-muted"><b>Packaging : </b> Carnets of 25, 50, 100 tickets, free tickets</p>
				
				<a href="generate-ticket.html"><button  type="button" class="btn btn-primary"><b>Process and Generate Ticket</b></button></a>
				
              <a href="print-ticket-edit.html" class="btn btn-primary"><b>Edit Details</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
		
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->