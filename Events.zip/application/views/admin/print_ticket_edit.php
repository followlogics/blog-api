<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit Print Ticket Order</h1>
      <ol class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Print Ticket Order</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-12">

          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title" style="margin: 8px 0px;">Edit Print Ticket Order</h3>
			  <a href="print-ticket.html"><button style="float: right" type="button" class="btn btn-primary">Back</button></a>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal">
              <div class="box-body">
                <div class="form-group">
                  <label for="promotername" class="col-sm-2 control-label">Promoter Name</label>
                  <div class="col-sm-10">
                    <input type="name" class="form-control" id="promotername" placeholder="Promoter Name">
                  </div>
                </div>
				<div class="form-group">
                  <label for="eventname" class="col-sm-2 control-label">Event Title</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="eventname" placeholder="Event Title">
                  </div>
                </div>
				<div class="form-group">
                  <label for="tickettype" class="col-sm-2 control-label">Ticket Type</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="tickettype" placeholder="Ticket Type">
                  </div>
                </div>
				<div class="form-group">
                  <label for="quantity" class="col-sm-2 control-label">No. of Ticket</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="quantity" placeholder="No. of Ticket">
                  </div>
                </div>
				<div class="form-group">
                  <label for="price" class="col-sm-2 control-label">Price per Ticket</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="price" placeholder="Price per Ticket">
                  </div>
                </div>
				<div class="form-group">
                  <label for="price" class="col-sm-2 control-label">Mode of Ticket</label>
                 <div class="col-sm-10">
                  <select class="form-control">
                    <option value="" selected="selected">Selct Mode</option>
                    <option value="Male">Online</option>
                    <option value="Female">Offline</option>
                  </select>
                  </div>
                </div>
				<div class="form-group">
				  <label for="price" class="col-sm-2 control-label">Type of Impression</label>
                  <div class="col-sm-10">
                    <div class="radio">
                    <label>
                      <input type="radio" onclick="javascript:yesnoCheck();" name="yesno" id="yesCheck"> Color (Choose Color)
                    </label>
                  </div>  
				<div id="ifYes" style="display:none;margin-left: 25px;">
				  <div class="radio">
                    <label>
                      <input type="radio" name="optionsRadios" id="optionsRadios3" value="red"> Paper Color: Red
                    </label>
                  </div> 
				  <div class="radio">
                    <label>
                      <input type="radio" name="optionsRadios" id="optionsRadios4" value="green"> Paper Color: Green
                    </label>
                  </div> 
				  <div class="radio">
                    <label>
                      <input type="radio" name="optionsRadios" id="optionsRadios5" value="blue"> Paper Color: Blue
                    </label>
                  </div> 
				</div>
				
				  <div class="radio">
                    <label>
                      <input type="radio" onclick="javascript:yesnoCheck();" name="yesno" id="noCheck"> Gray Scale (Paper Color: White)
                    </label>
                  </div>
                  </div>
                </div>
				<div class="form-group">
                  <label for="quantity" class="col-sm-2 control-label">Ticket Size</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" placeholder="139.5 x 54mm ( Corresponds to 8 tickets on a page )">
                  </div>
                </div>
				<div class="form-group">
                  <label for="quantity" class="col-sm-2 control-label">Packaging</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" placeholder="Carnets of 25, 50, 100 tickets, free tickets">
                  </div>
                </div>
				<div class="form-group">
                  <label for="quantity" class="col-sm-2 control-label">Poster Image on Ticket</label>
                  <div class="col-sm-10">
                    <input type="file" class="form-control" id="file">
                  </div>
                </div>
				<div class="form-group">
                  <label for="quantity" class="col-sm-2 control-label">Promoter Logo on Ticket</label>
                  <div class="col-sm-10">
                    <input type="file" class="form-control" id="file">
                  </div>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-default">Reset</button>
                <button type="submit" class="btn btn-info pull-right">Update Print Ticket Order</button>
              </div>
              <!-- /.box-footer -->
            </form>
			
          </div> 
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->