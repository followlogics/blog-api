<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Process & Generate Ticket</h1>
      <ol class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Process & Generate Ticket</li>
      </ol>
    </section>

    <!-- Main content -->
    <!-- Main content -->
    <section class="invoice">
      <!-- title row -->
	  <!-- Change Ticket Paper Color according to ticket type (like red, green, blue)  -->
      <div class="row print_ticket" title="Ticket Type 1 (Like General Ticket)">
        <div class="col-xs-3">
		<div style="border-right: 1px dotted;">
          <p style="margin: 0;">Promoter</p>
		  <h4 style="font-weight: bold;margin: 5px 0;">Event Title</h4>
		  <p style="margin: 0;">Event Date and Hour</p>
		  <p style="margin: 0;">VIP</p>
		  <p style="margin: 0;">1</p>
		  <p style="margin: 0;">A</p>
		  <p style="margin: 0;">1</p>
		  <p style="margin: 0;">20 $ CAD</p>
		  <p style="margin: 3px 0px 10px;font-size: 19px;">Ticket Number (10020)</p>
		  <img src="<?php echo base_url()?>assets/dist/img/qrcode.png" style="width: 65px; margin-bottom: 10px;">
		  <p>www.codticket.com</p>
        </div>
		</div>
        <!-- /.col -->
		<div class="col-xs-3" style="padding-left: 0px;">
          <img src="<?php echo base_url()?>assets/dist/img/event-poster.jpg" style="width: 100%; margin-bottom: 10px;">
		  <p style="text-align: center;margin: 0;">CONTACT</p>
		  <p style="font-size: 12px;text-align: center;">www.siteeventmanage.com tel:9911229933</p>
        </div>
        <!-- /.col -->
		<div class="col-xs-6">
		  <div class="col-xs-8" style="padding-left: 0px;">
		  <p style="text-align:center;font-size: 16px;">Promoter Name</p>
		  <h4 style="text-align:center;font-size: 26px;font-weight: bold;margin: 10px 0 20px;">Event Title</h4>
		  
		  <p style="text-align:center;font-size: 16px;">Event Address</p>
		  <h4 style="text-align:center;font-size: 22px;font-weight: bold;">Event Date and Hour</h4>
		  </div>
		  <div class="col-xs-4" style="padding-right: 0px;">
		  <img src="<?php echo base_url()?>assets/dist/img/event-logo.jpg" style="width: 100px; margin-bottom: 10px; float:right;">
		  </div>
		  <div class="col-xs-12" style="padding-left: 0px;padding-right: 0px;">
		  <table class="table" style="font-size: 17px;">
              <tr>
                <td style="border: none;padding-left: 0px;">Ticket Type (VIP)</td>
                <td style="border: none;">Section <b>1</b></td>
				<td style="border: none;">Row <b>A</b></td>
                <td style="border: none;">Seat <b>1</b></td>
              </tr>
            </table>
		  <table class="table" style="font-size: 17px;margin-bottom: 0px;">
              <tr>
                <td style="border: none;padding-left: 0px;">Price <b>20 $CAD</b></td>
                <td style="border: none;"><b>Ticket Number (10020)</b></td>
				<td rowspan="2" style="border: none;padding-right: 0px;text-align: right;">
				<img src="<?php echo base_url()?>assets/dist/img/qrcode.png" style="width: 75px; margin-bottom: 10px;"></td>
              </tr>
			  <tr>
                <td style="border: none;font-size: 13px;text-align: center;padding-left: 0px;">Issue Date : 11/03/2017</td>
                <td style="border: none;font-size: 13px;text-align: center;">www.codticket.com</td>
              </tr>
            </table>
		  </div>
        </div>
        <!-- /.col -->
      </div>
	  
	  <!-- Change Ticket Paper Color according to ticket type (like red, green, blue)  -->
      <div class="row print_ticket-2" title="Ticket Type 2 (Like VIP Ticket Change Paper Color)">
        <div class="col-xs-3">
		<div style="border-right: 1px dotted;">
          <p style="margin: 0;">Promoter</p>
		  <h4 style="font-weight: bold;margin: 5px 0;">Event Title</h4>
		  <p style="margin: 0;">Event Date and Hour</p>
		  <p style="margin: 0;">VIP</p>
		  <p style="margin: 0;">1</p>
		  <p style="margin: 0;">A</p>
		  <p style="margin: 0;">1</p>
		  <p style="margin: 0;">20 $ CAD</p>
		  <p style="margin: 3px 0px 10px;font-size: 19px;">Ticket Number (10020)</p>
		  <img src="<?php echo base_url()?>assets/dist/img/qrcode.png" style="width: 65px; margin-bottom: 10px;">
		  <p>www.codticket.com</p>
        </div>
		</div>
        <!-- /.col -->
		<div class="col-xs-3" style="padding-left: 0px;">
          <img src="<?php echo base_url()?>assets/dist/img/event-poster.jpg" style="width: 100%; margin-bottom: 10px;">
		  <p style="text-align: center;margin: 0;">CONTACT</p>
		  <p style="font-size: 12px;text-align: center;">www.siteeventmanage.com tel:9911229933</p>
        </div>
        <!-- /.col -->
		<div class="col-xs-6">
		  <div class="col-xs-8" style="padding-left: 0px;">
		  <p style="text-align:center;font-size: 16px;">Promoter Name</p>
		  <h4 style="text-align:center;font-size: 26px;font-weight: bold;margin: 10px 0 20px;">Event Title</h4>
		  
		  <p style="text-align:center;font-size: 16px;">Event Address</p>
		  <h4 style="text-align:center;font-size: 22px;font-weight: bold;">Event Date and Hour</h4>
		  </div>
		  <div class="col-xs-4" style="padding-right: 0px;">
		  <img src="<?php echo base_url()?>assets/dist/img/event-logo.jpg" style="width: 100px; margin-bottom: 10px; float:right;">
		  </div>
		  <div class="col-xs-12" style="padding-left: 0px;padding-right: 0px;">
		  <table class="table" style="font-size: 17px;">
              <tr>
                <td style="border: none;padding-left: 0px;">Ticket Type (VIP)</td>
                <td style="border: none;">Section <b>1</b></td>
				<td style="border: none;">Row <b>A</b></td>
                <td style="border: none;">Seat <b>1</b></td>
              </tr>
            </table>
		  <table class="table" style="font-size: 17px;margin-bottom: 0px;">
              <tr>
                <td style="border: none;padding-left: 0px;">Price <b>20 $CAD</b></td>
                <td style="border: none;"><b>Ticket Number (10020)</b></td>
				<td rowspan="2" style="border: none;padding-right: 0px;text-align: right;">
				<img src="<?php echo base_url()?>assets/dist/img/qrcode.png" style="width: 75px; margin-bottom: 10px;"></td>
              </tr>
			  <tr>
                <td style="border: none;font-size: 13px;text-align: center;padding-left: 0px;">Issue Date : 11/03/2017</td>
                <td style="border: none;font-size: 13px;text-align: center;">www.codticket.com</td>
              </tr>
            </table>
		  </div>
        </div>
        <!-- /.col -->
      </div>
	  
	  <!-- Change Ticket Paper Color according to ticket type (like red, green, blue)  -->
      <div class="row print_ticket-3" title="Ticket Type 3 (Like VIP Ticket Change Paper Color)">
        <div class="col-xs-3">
		<div style="border-right: 1px dotted;">
          <p style="margin: 0;">Promoter</p>
		  <h4 style="font-weight: bold;margin: 5px 0;">Event Title</h4>
		  <p style="margin: 0;">Event Date and Hour</p>
		  <p style="margin: 0;">VIP</p>
		  <p style="margin: 0;">1</p>
		  <p style="margin: 0;">A</p>
		  <p style="margin: 0;">1</p>
		  <p style="margin: 0;">20 $ CAD</p>
		  <p style="margin: 3px 0px 10px;font-size: 19px;">Ticket Number (10020)</p>
		  <img src="<?php echo base_url()?>assets/dist/img/qrcode.png" style="width: 65px; margin-bottom: 10px;">
		  <p>www.codticket.com</p>
        </div>
		</div>
        <!-- /.col -->
		<div class="col-xs-3" style="padding-left: 0px;">
          <img src="<?php echo base_url()?>assets/dist/img/event-poster.jpg" style="width: 100%; margin-bottom: 10px;">
		  <p style="text-align: center;margin: 0;">CONTACT</p>
		  <p style="font-size: 12px;text-align: center;">www.siteeventmanage.com tel:9911229933</p>
        </div>
        <!-- /.col -->
		<div class="col-xs-6">
		  <div class="col-xs-8" style="padding-left: 0px;">
		  <p style="text-align:center;font-size: 16px;">Promoter Name</p>
		  <h4 style="text-align:center;font-size: 26px;font-weight: bold;margin: 10px 0 20px;">Event Title</h4>
		  
		  <p style="text-align:center;font-size: 16px;">Event Address</p>
		  <h4 style="text-align:center;font-size: 22px;font-weight: bold;">Event Date and Hour</h4>
		  </div>
		  <div class="col-xs-4" style="padding-right: 0px;">
		  <img src="<?php echo base_url()?>assets/dist/img/event-logo.jpg" style="width: 100px; margin-bottom: 10px; float:right;">
		  </div>
		  <div class="col-xs-12" style="padding-left: 0px;padding-right: 0px;">
		  <table class="table" style="font-size: 17px;">
              <tr>
                <td style="border: none;padding-left: 0px;">Ticket Type (VIP)</td>
                <td style="border: none;">Section <b>1</b></td>
				<td style="border: none;">Row <b>A</b></td>
                <td style="border: none;">Seat <b>1</b></td>
              </tr>
            </table>
		  <table class="table" style="font-size: 17px;margin-bottom: 0px;">
              <tr>
                <td style="border: none;padding-left: 0px;">Price <b>20 $CAD</b></td>
                <td style="border: none;"><b>Ticket Number (10020)</b></td>
				<td rowspan="2" style="border: none;padding-right: 0px;text-align: right;">
				<img src="<?php echo base_url()?>assets/dist/img/qrcode.png" style="width: 75px; margin-bottom: 10px;"></td>
              </tr>
			  <tr>
                <td style="border: none;font-size: 13px;text-align: center;padding-left: 0px;">Issue Date : 11/03/2017</td>
                <td style="border: none;font-size: 13px;text-align: center;">www.codticket.com</td>
              </tr>
            </table>
		  </div>
        </div>
        <!-- /.col -->
      </div>
      
      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print Ticket</a>
          <button type="button" class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Request to Promoter
          </button>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->