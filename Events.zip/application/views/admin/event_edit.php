<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit Event</h1>
      <ol class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Event</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-12">

          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title" style="margin: 8px 0px;">Edit Event</h3>
			  <a href="<?php echo base_url()?>index.php/admin/manageEvents"><button style="float: right" type="button" class="btn btn-primary">Back</button></a>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal">
              <div class="box-body">
                <div class="form-group">
                  <label for="firstname" class="col-sm-2 control-label">Event Name</label>
                  <div class="col-sm-10">
                    <input type="name" class="form-control" id="firstname" placeholder="Event Name">
                  </div>
                </div>
				<div class="form-group">
                  <label for="lastname" class="col-sm-2 control-label">Location</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="lastname" placeholder="Location">
                  </div>
                </div>
				<div class="form-group">
                  <label for="dob" class="col-sm-2 control-label">Start Date</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="datepicker" placeholder="Start Date">
                  </div>
                </div>
				<div class="form-group">
                  <label for="dob" class="col-sm-2 control-label">End Date</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="datepicker1" placeholder="End Date">
                  </div>
                </div>
				<div class="form-group">
                  <label for="eventimg" class="col-sm-2 control-label">Event Image</label>
                  <div class="col-sm-10">
                    <input type="file" class="form-control" id="file">
                  </div>
                </div>
				<div class="form-group">
                  <label for="eventdescription" class="col-sm-2 control-label">Event Description</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" rows="3" placeholder="Event Description"></textarea>
                  </div>
                </div>
				<div class="form-group">
                  <label for="organisername" class="col-sm-2 control-label">Organiser Name</label>
                  <div class="col-sm-10">
                    <input type="name" class="form-control" id="organisername" placeholder="Organiser Name">
                  </div>
                </div>
				<div class="form-group">
                  <label for="organiserdescription" class="col-sm-2 control-label">Organiser Description</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" rows="3" placeholder="Organiser Description"></textarea>
                  </div>
                </div>
				<div class="form-group">
                  <label for="organiserimg" class="col-sm-2 control-label">Organiser Image</label>
                  <div class="col-sm-10">
                    <input type="file" class="form-control" id="file">
                  </div>
                </div>
				<div class="form-group">
                  <label for="Eventtype" class="col-sm-2 control-label">Event Type</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="Eventtype" placeholder="Event Type">
                  </div>
                </div>
				<div class="form-group">
                  <label for="eventtopic" class="col-sm-2 control-label">Event Topic</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="eventtopic" placeholder="Event Topic">
                  </div>
                </div>
				<div class="form-group">
                  <label for="eventtopic" class="col-sm-2 control-label">Social Media Links</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" rows="1" placeholder="Add Social Media Links"></textarea>
                  </div>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-default">Reset</button>
                <button type="submit" class="btn btn-info pull-right">Update Event</button>
              </div>
              <!-- /.box-footer -->
            </form>
			
          </div> 
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->