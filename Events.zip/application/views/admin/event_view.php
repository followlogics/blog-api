<!--Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <?php $evnt_id = $this->uri->segment(3,0);?>
    <!-- Content Header (Page header) -->
    <?php //$query = $this->db->get_where('events', array('event_id' => $evnt_id));
           $this->db->select('*');
           $this->db->from('events');
           $this->db->where('event_id',$evnt_id);
           $query = $this->db->get();
           $row = $query->row_array();
           //echo "<pre>";
           //print_r($row);
           //echo $this->db->last_query();die;

    ?>
    <section class="content-header">
      <h1><?php echo $row['event_title']?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url()?>index.php/admin/manageEvents"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">View Event</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="img-responsive" src="<?php echo base_url()?>assets/images/eventimage/<?php echo $row['event_image']?>" alt="User profile picture"">

              <h3 class="profile-username text-center"><?php echo $row['event_title']?></h3>

              <p class="text-muted text-center"><b>Status : </b> <?php echo $row['event_status']?></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Event Type</b> <a class="pull-right"><?php echo $row['event_type'] == 'Other' ? $row['otherEventType'] : $row['event_type'];?></a>
                </li>
                <li class="list-group-item">
                  <b>Start Date</b> <a class="pull-right"><?php $str =$row['event_startdate'] ;echo  $str=substr($str, 0, strrpos($str, ' '));?></a>
                </li>
                <li class="list-group-item">
                  <b>End Date</b> <a class="pull-right"><?php $str =$row['event_enddate'] ;echo  $str=substr($str, 0, strrpos($str, ' '));?></a>
                </li>
              </ul>

              <a href="<?php echo base_url()?>index.php/admin/manageEvents" class="btn btn-primary btn-block"><b>Back</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-6">
		
		<!-- About Me Box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo $row['event_title']?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i>Event Details</strong>
				</br></br>
			  <p class="text-muted"><b>Event Name : </b> <?php echo $row['event_title']?></p>
              <p class="text-muted"><b>Event Description : </b> <?php echo $row['event_description']?></p>
			  <!-- <p class="text-muted"><b>Social Link : </b> www.facebook.com</p> -->
			  <p class="text-muted"><b>Ticket Type : </b> </p>
              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
					</br></br>
              <p class="text-muted"><b>Address : </b> <?php echo $row['event_location']?></p>
			  
			   <a href="<?php echo base_url()?>index.php/admin/eventEdit/<?php echo $row['event_id']?>" class="btn btn-primary"><b>Edit Event</b></a>
			  <button class="btn btn-primary" data-toggle="modal" data-target="#myModal" style=" background-color: #f00; border-color: #f00;"><b>Print Ticket Request for Above Event</b></button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content" style="text-align: center;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Print Ticket Request</h4>
      </div>
      <div class="modal-body">
        <p><b>Number of Ticket :</b> 200</p>
		<p><b>Ticket Type :</b> General</p>
		<a href="print-ticket-view.html" class="btn btn-primary"><b>Proceed to Print</b></a>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!-- End Modal -->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
		
        </div>
        <!-- /.col -->
		<div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
           
              <!-- <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url()?>assets/dist/img/user2-160x160.jpg" alt="User profile picture"> -->
              <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url()?>assets/images/eventimage/<?php echo $row['event_organiser_image']?>" alt="User profile picture">

              <h3 class="profile-username text-center"></h3>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Organiser Name</b> <a class="pull-right"><?php echo $row['event_organiser_name']?></a>
                </li>
              </ul>

              <p class="text-muted text-center"><?php echo $row['event_organiser_description']?></p>

              <a href="<?php echo base_url()?>index.php/admin/manageEvents" class="btn btn-primary btn-block"><b>Back</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper