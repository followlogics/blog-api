<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Codticket | Dashboard</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/dist/css/AdminLTE.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/admin_style.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/iCheck/flat/blue.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/morris/morris.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/toastr.min.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/datepicker/datepicker3.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <script src="<?php echo base_url()?>assets/plugins/jQuery/jquery-2.2.3.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/toastr.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery_validation/jquery.validate.js"></script>
  <script type="text/javascript">
        toastr.options = {
  "closeButton": true,
  "debug": false,
  "newestOnTop": false,
  "progressBar": true,
  "positionClass": "toast-top-right",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "300",
  "hideDuration": "1000",
  "timeOut": "5000",
  "extendedTimeOut": "1000",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
  </script>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="index.html" class="logo">
      <span class="logo-mini"><b>C</b>T</span>
      <span class="logo-lg"><b>Cod</b>Ticket</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning">4</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 4 notifications</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
				  <li><a href="print-ticket-view.html"><i class="fa fa-shopping-cart text-green"></i> 200 General ticket printing request </a></li>
                  <li><a href="print-ticket-view.html"><i class="fa fa-shopping-cart text-green"></i> 500 VIP ticket printing request </a></li>
                  <li><a href="promoter-view.html"><i class="fa fa-user text-aqua"></i> 1 new Promoter joined today</a></li>
                  <li><a href="buyer-view.html"><i class="fa fa-user text-yellow"></i> 1 new Buyer joined today</a></li>
                  <li><a href="event-view.html"><i class="fa fa-th text-red"></i> 1 new Event added today</a></li>
                </ul>
              </li>
              <li class="footer"><a href="notification.html">View all</a></li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo base_url()?>assets/dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $this->session->userdata('fname') ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo base_url()?>assets/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                <p>
                  Admin Name - <?php echo $this->session->userdata('fname') ?>
                  <small>Member since Nov. 2012</small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="<?php echo base_url()?>index.php/admin/adminProfile" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="<?php echo base_url()?>index.php/admin/logout" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Logout  Button -->
          <li><a href="#" data-toggle="control-sidebar"><i class="fa fa-lock"></i></a></li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo base_url()?>assets/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Admin Name</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview"><a href="index.html"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li class="treeview">
          <a href="#"><i class="fa fa-users"></i><span>User Management</span>
		    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
		  </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url()?>index.php/admin/promoters"><i class="fa fa-circle-o"></i> Promoter</a></li>
            <li><a href="<?php echo base_url()?>index.php/admin/buyers"><i class="fa fa-circle-o"></i> Buyer</a></li>
          </ul>
        </li>
        <li><a href="<?php echo base_url()?>index.php/admin/manageEvents"><i class="fa fa-th"></i> <span>Manage events</span></a></li>
         <li class="treeview"><a href="<?php echo base_url()?>index.php/admin/Generateticket"><i class="fa fa-pie-chart"></i><span>Generate tickets</span></a></li>
         
        <li class="treeview"><a href="<?php echo base_url()?>index.php/admin/printTicket"><i class="fa fa-laptop"></i><span>Print tickets</span></a></li>
       
	     	<li class="treeview">
          <a href="#">
            <i class="fa fa-gears"></i> <span>Setting</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url()?>index.php/admin/adminProfile"><i class="fa fa-circle-o"></i> My Profile</a></li>
            <li><a href="<?php echo base_url()?>index.php/admin/editProfile"><i class="fa fa-circle-o"></i> Edit Profile</a></li>
            <li><a href="<?php echo base_url()?>index.php/admin/changePassword"><i class="fa fa-circle-o"></i> Change Password</a></li>
          </ul>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>