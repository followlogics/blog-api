<div class="container-fluid header-1">
<div class="header-content">
<h1>Who We Are</h1>
<h3><a href="<?php echo base_url();?>">Home</a> > Who We Are</h3>
</div>
</div>
	
	<div class="container space-top border-rj">
	<div class="row">
    <div class="col-md-6">
	<img src="<?php echo base_url()?>assets/images/about.jpg">
	</div>
    <div class="col-md-6">
	<div class="event">
	<h1>Who We Are </h1>
	<p></p>
	</div>
	<div class="event-block">
	<p><b>CodTicket ™</b>  is a ticketing company that aims to securely produce and validate tickets for sports, recreational or other activities requiring authentication at the entrance of the public. </p>	
	<p>The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.</p>	
	</div>
	</div>
    </div>	
	</div>
	
	
	<div class="container space-top-1">
	<h1 class="heading" style="text-align:center;">What Our Clients Say</h1>
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class="carousel slide" id="fade-quote-carousel" data-ride="carousel" data-interval="3000">
				  <!-- Carousel indicators -->
                  <ol class="carousel-indicators">
				    <li data-target="#fade-quote-carousel" data-slide-to="0" class="active"></li>
				    <li data-target="#fade-quote-carousel" data-slide-to="1"></li>
				    <li data-target="#fade-quote-carousel" data-slide-to="2"></li>
				  </ol>
				  <!-- Carousel items -->
				  <div class="carousel-inner">
				    <div class="active item">
                        <div class="profile-circle" style="background-color: rgba(0,0,0,.2);"><img src="<?php echo base_url()?>assets/images/test-1.png"></div>
				    	<blockquote>
				    		<p>Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room.</p>
							<p><b>Alex Bonchenky</b> &nbsp; &nbsp; <b style="color: #09c;">CEO Glove Pvt. Ltd.</b></p>
				    	</blockquote>	
				    </div>
					<div class="item">
                        <div class="profile-circle" style="background-color: rgba(0,0,0,.2);"><img src="images/test-1.png"></div>
				    	<blockquote>
				    		<p>Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room.</p>
							<p><b>Alex Bonchenky</b> &nbsp; &nbsp; <b style="color: #09c;">CEO Glove Pvt. Ltd.</b></p>
				    	</blockquote>	
				    </div>
					<div class="item">
                        <div class="profile-circle" style="background-color: rgba(0,0,0,.2);"><img src="<?php echo base_url()?>assets/images/test-1.png"></div>
				    	<blockquote>
				    		<p>Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room.</p>
							<p><b>Alex Bonchenky</b> &nbsp; &nbsp; <b style="color: #09c;">CEO Glove Pvt. Ltd.</b></p>
				    	</blockquote>	
				    </div>
				  </div>
				</div>
			</div>							
		</div>
	</div>