<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit Promoter Detail</h1>
      <ol class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Promoter Detail</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-12">

          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title" style="margin: 8px 0px;">Edit Promoter Detail</h3>
			  <a href="<?php echo base_url()?>index.php/admin/promoters"><button style="float: right" type="button" class="btn btn-primary">Back</button></a>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?php  $buyer_id = $this->uri->segment(3, 0);
                   $query = $this->db->get_where('users', array('user_id' => $buyer_id));
                   $result = $query->result();
            ?>
           <!--  <form class="form-horizontal"> -->
           <?php 
                  $attributes = array('class' => 'form-horizontal');
                  echo form_open('admin/buyereditProfile', $attributes);
              ?>
                    <div class="box-body">
                <div class="form-group">
                  <label for="firstname" class="col-sm-2 control-label">First Name</label>
                  <div class="col-sm-10">
                    <input type="name" class="form-control" id="firstname" placeholder="First Name" name="firstname" value="<?php echo $result[0]->first_name ?>">
                  </div>
                </div>
        <div class="form-group">
                  <label for="lastname" class="col-sm-2 control-label">Last Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="lastname" placeholder="Last Name" name="lastname" value="<?php echo $result[0]->last_name ?>">
                  </div>
                </div>
        <div class="form-group">
                  <label for="phone" class="col-sm-2 control-label">Phone No.</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="phone" placeholder="Phone Number" name="phonenumber" value="<?php echo $result[0]->phone_number ?>">
                  </div>
                </div>
        
        <div class="form-group">
                  <label for="email" class="col-sm-2 control-label">Email Address</label>
                  <div class="col-sm-10">
                    <input type="email" class="form-control" id="email" placeholder="Email Address" name="email" value="<?php echo $result[0]->email ?>">
                  </div>
                </div>
        
                <div class="form-group">
                  <label for="homeaddress" class="col-sm-2 control-label">Home Address</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" rows="3" placeholder="Home Address" name="home_address"><?php echo $result[0]->home_address ?></textarea>
                  </div>
                </div>
        
                <div class="form-group">
                  <label for="billingaddress" class="col-sm-2 control-label">Office Address</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" rows="3" placeholder="Billing Address" name="office_address"><?php echo $result[0]->office_address ?></textarea>
                  </div>
                </div>
        <div class="form-group">
                  <label for="gender" class="col-sm-2 control-label">Gender</label>
                  <div class="col-sm-10">
                  <select class="form-control">
                    <option value="">Selct Gender</option>
                    <option value="Male" <?php if($result[0]->gender =="Male") echo 'selected="selected"';?>>Male</option>
                    <option value="Female" <?php if($result[0]->gender =="Female") echo 'selected="selected"';?>>Female</option>
                  </select>
                  </div>
                </div>
        <div class="form-group">
                  <label for="dob" class="col-sm-2 control-label">Date of Birth</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="datepicker" placeholder="Select DOB" name="dob" value="<?php echo $result[0]->date_of_birth ?>">
                  </div>
                </div>
                <input type="hidden" name="form_user" value="<?php echo $buyer_id ?>">
        
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-default">Reset</button>
                <button type="submit" class="btn btn-info pull-right" name="editaction" value="submit">Update</button>  
              </div>
              <!-- /.box-footer -->
            </form>
			
          </div> 
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->