<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(
	             'user/do_signup' => array(
                         array(
                         	    'field' => 'firstname',
                         	    'label' =>'firstname',
                         	    'rules'  => 'trim|required'
                         	  
                         	),
                         array(
                         	    'field' => 'lastname',
                         	    'label' =>'lastname',
                         	    'rules'  => 'trim|required',
                         	    'errors' => array('required' => 'Please provide a %s')
                         	),
                         array(
                         	    'field' => 'email',
                         	    'label' =>'email',
                         	    'rules' => 'required|valid_email|is_unique[users.email]',
	                 	        'errors'=>array(
	                 	        'is_unique'=>'this %s already exists.','valid_email' => 'Please provide a valid email'
	                 	        )
                         	),
                         array(
                         	    'field' => 'phone',
                         	    'label' =>'phone',
                         	    'rules'  => 'trim|required',
                         	    'errors' => array('required' => 'Please provide a %s')
                         	),
                         array(
                         	    'field' => 'password',
                         	    'label' =>'password',
                         	    'rules'  => 'trim|required',
                         	    'errors' => array('required' => 'Please provide a %s')
                         	),
                         array(
                         	    'field' => 'confirmpasswd',
                         	    'label' =>'confirmpasswd',
                         	    'rules'  => 'trim|required|matches[password]',
                         	    'errors' => array('required' => 'Please provide a %s')
                         	),
	             	    ),
                  'user/do_login' => array(
                         array(
                                  'field' => 'username',
                                  'label' =>'Username',
                                  'rules'  => 'trim|required',
                                  'errors' => array('required' => 'Please provide a %s')
                                
                              ),
                         array(
                                  'field' => 'password',
                                  'label' =>'Password',
                                  'rules'  => 'trim|required',
                                  'errors' => array('required' => 'Please provide a %s')
                              )
                         )

                 
	    );
$config['error_prefix'] = '<div class="error_prefix">';
$config['error_suffix'] = '</div>';