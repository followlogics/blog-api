<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Event Ticket Selling</title>
        <link href="<?php echo base_url() ?>assets/css/bootstrap.css" rel="stylesheet">
        <link href="<?php echo base_url() ?>assets/css/font-awesome.css" rel="stylesheet">
        <link href="<?php echo base_url() ?>assets/css/font-awesome.css" rel="stylesheet">
        <link href="<?php echo base_url() ?>assets/css/style.css" rel="stylesheet">
        <link href="<?php echo base_url() ?>assets/css/jquery.datetimepicker.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/toastr.min.css">
        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-2.1.4.js"></script>
        <script src="<?php echo base_url() ?>assets/js/toastr.min.js"></script>
        <script src="<?php echo base_url() ?>assets/js/bootstrap.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery_validation/jquery.validate.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/countries.js"></script>
        <script src="<?php echo base_url() ?>assets/js/jquery.datetimepicker.full.js"></script>
        <script type="text/javascript">
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        </script>
    </head>
    <body>
        <nav class="navbar navbar-default">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="logo" href="<?php echo base_url(); ?>"><img src="<?php echo base_url() ?>assets/images/logo.png"></a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="<?php echo base_url() ?>">Home</a></li>
                        <li><a href="<?php echo base_url() ?>index.php/user/aboutPage">Who We Are</a></li>
                        <li><a href="<?php echo base_url() ?>index.php/user/discoveryEvent">Discovery Event</a></li>
                        <li><a href="<?php echo base_url() ?>index.php/user/ourSolutions">Our Solution</a></li>
                        <li><a href="<?php echo base_url() ?>index.php/user/contactus">Contact Us</a></li>
                        <?php if ($this->session->userdata('userrole') !== 'buyer') { ?>
                            <li><a href="<?php echo base_url() ?>index.php/user/eventcreate" <?php echo $this->session->userdata('frntuser') == '' ? "id=modelLogin" : " "; ?>>Create Event</a></li>
                        <?php } ?>
                        <?php if ($this->session->userdata('userrole') == '') { ?>
                            <li class="login-bt"><a href="<?php echo base_url() ?>index.php/user/do_login">Sign in / Sign Up</a></li>
                        <?php } ?>

                        <?php if ($this->session->userdata('user_id') != '') { ?>
                            <li class="dropdown login-bt">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                    <img src="<?php echo base_url() ?>assets/images/client.jpg" style="width: 20px;border-radius: 100px;"> &nbsp; &nbsp; <?php echo $this->session->userdata('fname') . ' ' . $this->session->userdata('lname') ?> <span class="caret"></span></a>
                                <!-- <ul class="dropdown-menu">
                                  <li style="text-align: center;"><a href="buyer-profile.html"><img src="<?php echo base_url() ?>assets/images/client.jpg" style="width: 70px;border-radius: 100px; margin-bottom:10px;"> </br> Chester Bennington</a></li>
                                  <li role="separator" class="divider"></li>
                                  <li style="text-align: center;"><a href="<?php echo base_url() ?>index.php/user/logout">Logout</a></li>
                                </ul> -->
                                <ul class="dropdown-menu">
                                    <li style="text-align: center;"><img src="<?php echo base_url() ?>assets/images/client.jpg" style="width: 70px;border-radius: 100px; margin-bottom:10px;">
                                        <form name="upload_file" id="upload_file" enctype="multipart/form-data" action="<?php echo base_url() ?>index.php/user/profilepic" method="POST">

                                            <span class="select-wrapper"><input type="file" name="image_src" id="image_src" /></span>
                                        </form>
                                        </br> <?php echo $this->session->userdata('fname') ?></li>
                                    <li role="separator" class="divider"></li>
                                    <li style="text-align: center;">
                                        <?php if ($this->session->userdata('userrole') == 'buyer') { ?>
                                            <a href="<?php echo base_url() ?>index.php/user/buyerProfile" class="btn btn-outline-profile">Profile</a> 
                                        <?php } else if ($this->session->userdata('userrole') == 'promoter') { ?>
                                            <a href="<?php echo base_url() ?>index.php/user/promoterProfile" class="btn btn-outline-profile">Profile</a>
                                        <?php } ?>
                                        <a href="<?php echo base_url() ?>index.php/user/logout" class="btn btn-outline-profile">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        <?php } ?>
                        <!--<li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="#">Action</a></li>
                    <li><a href="#">Another action</a></li>
                    <li><a href="#">Something else here</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="#">Separated link</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="#">One more separated link</a></li>
                  </ul>
                </li>-->

                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
        <!-- login model -->
        <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="loginmodel">
            <div class="modal-dialog modal-sm">  
                <div class="modal-content">
                    <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-12">                    
                        <div class="panel panel-info" >
                            <div class="panel-heading">
                                <div class="panel-title">Sign In</div>
                                <div style="float:right; font-size: 80%; position: relative; top:-19px"><a href="<?php echo base_url() ?>index.php/user/forget" style="color:#fff">Forgot password?</a></div>
                            </div>     
                            <div id="status">
                                <div style="padding-top:30px" class="panel-body" >

                                    <!-- <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div> -->
                                    <div id="login_response"><!-- spanner --></div> 

                                    <form id="loginModelForm" class="form-horizontal" role="form" method="post">

                                        <div style="margin-bottom: 25px" class="input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                            <input id="mdUsername" type="text" class="form-control" name="mdUsername" value="" placeholder="username or email" required>                                        
                                        </div>

                                        <div style="margin-bottom: 25px" class="input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                            <input id="mdPassword" type="password" class="form-control" name="mdPassword" placeholder="password" required>
                                        </div>



                                        <div class="input-group">
                                            <div class="checkbox">
                                                <label>
                                                    <input id="login-remember" type="checkbox" name="remember" value="1"> Remember me
                                                </label>
                                            </div>
                                        </div>


                                        <div style="margin-top:10px" class="form-group">
                                            <!-- Button -->

                                            <div class="col-sm-12 controls">
                                                <!-- <a id="btn-login" href="#" class="btn-new btn-success">Login  </a>
                                                 <a id="btn-fblogin" href="#" class="btn-new btn-primary">Login with Facebook</a>-->
                                                <button id="btn-login1" type="submit" class="btn-new btn-info" name="loginModelbt" value="submit" ><i class="icon-hand-right"></i> &nbsp Login</button>

                                            </div>
                                            <div id="ajax_loading" style="display: none;">
                                                <img align="absmiddle" src="<?php echo base_url() ?>assets/images/spinner.gif" style="width: 10%;padding-left: 13px;">&nbsp;&nbsp;Processing...
                                            </div>
                                        </div>

                                    </form>  </div>
                                <div class="form-group">
                                    <div class="col-md-12 control">
                                        <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
                                            Don't have an account! 
                                            <a href="<?php echo base_url() ?>index.php/user/do_signup">Sign Up Here</a>
                                        </div>
                                    </div>
                                </div>    




                            </div>                     
                        </div>  
                    </div>
                </div>
            </div>
        </div>
        <!--model login end-->
        <!-- <script type="text/javascript">
          $('#file').change(function() {
        
              var url = $("#upload_file").attr('action');
        
              var inputFile = $('input[name=file]');
              console.log(inputFile);
              var fileToUpload = inputFile[0].files[0];
              console.log(fileToUpload);
              if(fileToUpload !='undefined'){
              var formData = new FormData();
              formData.append('file',fileToUpload);
        
              $.ajax({
              url: url,
              type: 'POST',
              data: fileToUpload,
              processData: false,
              async: false,
              success: function (res) {
                  
              },
              error: function (error) {
                
              }
              }); 
        
              }
            
        
        });
        
        </script> -->
        <script type="text/javascript">
            $('#image_src').change(function () {
                var url = $("#upload_file").attr('action');
                console.log(url);
                var formData = new FormData($("#upload_file")[0]);

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    async: false,
                    success: function (res) {
                        //console.log(res);
                    },
                    error: function (error) {
                        // console.log(error);
                    }
                }); // End: $.ajax()           

            });

            // When DOM is ready
            $(document).ready(function () {

                // Launch MODAL BOX if the Login Link is clicked
                $("#modelLogin").click(function () {
                    $("#modelLogin").removeAttr("href").css("cursor", "pointer");
                    ;
                    $('#loginmodel').modal();
                });

                // When the form is submitted
                $("#loginModelForm").submit(function () {
                    //console.log('hi');
                    // Hide 'Submit' Button
                    $('#btn-login1').hide();

                    // Show Gif Spinning Rotator
                    $('#ajax_loading').show();

                    // 'this' refers to the current submitted form  
                    var str = $(this).serialize();

                    // -- Start AJAX Call --

                    $.ajax({
                        type: "POST",
                        url: "<?php echo base_url() ?>index.php/user/do_Modellogin",
                        data: str,
                        success: function (msg) {

                            $(document).ajaxComplete(function (event, request, settings) {

                                // Show 'Submit' Button
                                $('#btn-login1').show();

                                // Hide Gif Spinning Rotator
                                $('#ajax_loading').hide();

                                if (msg == 'OK') // LOGIN OK?
                                {
                                    var login_response = '<div id="logged_in">' +
                                            '<div style="width: 350px; float: left; margin-left: 70px;">' +
                                            '<div style="width: 40px; float: left;">' +
                                            '<img style="margin: 10px 0px 10px 0px;" align="absmiddle" src="images/ajax-loader.gif">' +
                                            '</div>' +
                                            '<div style="margin: 10px 0px 0px 10px; float: right; width: 300px;">' +
                                            "You are successfully logged in! <br /> Please wait while you're redirected...</div></div>";

                                    $('#loginmodel').hide();

                                    $('#simplemodal-container').css("width", "500px");
                                    $('#simplemodal-container').css("height", "120px");

                                    $('#loginmodel').html(login_response); // Refers to 'status'

                                    // After 3 seconds redirect the 
                                    setTimeout('go_to_private_page()', 500);
                                } else // ERROR?
                                {
                                    var login_response = msg;
                                    $('#login_response').html(login_response);
                                }

                            });

                        }

                    });

                    // -- End AJAX Call --

                    return false;

                }); // end submit event

            });

            function go_to_private_page()
            {
                window.location = '<?php echo base_url() ?>index.php/user/eventcreate'; // Members Area
            }
        </script>
        <style type="text/css">
            #login_response{color: red;}
        </style>

