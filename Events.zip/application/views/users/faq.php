<div class="container-fluid header-1">
<div class="header-content">
<h1>FAQs</h1>
<h3><a href="index.html">Home</a> > FAQs</h3>
</div>
</div>
	
	<div class="container space-top border-rj">
	<div class="row">
	<div class="col-md-8 col-md-offset-2 col-pad">
    <div class="panel-group" id="faqAccordion">
        <div class="panel panel-default ">
            <div class="panel-heading accordion-toggle question-toggle collapsed" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question0">
                 <h4 class="panel-title">
                    <a href="#" class="ing">Q : What is Codticket?</a>
              </h4>

            </div>
            <div id="question0" class="panel-collapse collapse in" style="height: auto;">
                <div class="panel-body">
                     <h5><span class="label label-primary">Answer</span></h5>

                    <p>The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.</p>
                </div>
            </div>
        </div>
        <div class="panel panel-default ">
            <div class="panel-heading accordion-toggle collapsed question-toggle" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question1">
                 <h4 class="panel-title">
                    <a href="#" class="ing">Q : Why do we use it?</a>
              </h4>

            </div>
            <div id="question1" class="panel-collapse collapse in" style="height: auto;">
                <div class="panel-body">
                     <h5><span class="label label-primary">Answer</span></h5>

                    <p>The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.</p>
                </div>
            </div>
        </div>
        <div class="panel panel-default ">
            <div class="panel-heading accordion-toggle collapsed question-toggle" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question2">
                 <h4 class="panel-title">
                    <a href="#" class="ing">Q : Where does it come from?</a>
              </h4>

            </div>
            <div id="question2" class="panel-collapse collapse in" style="height: auto;">
                <div class="panel-body">
                     <h5><span class="label label-primary">Answer</span></h5>

                    <p>The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.</p>
                </div>
            </div>
        </div>
        <div class="panel panel-default ">
            <div class="panel-heading accordion-toggle collapsed question-toggle" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question3">
                 <h4 class="panel-title">
                    <a href="#" class="ing">Q : Where can I get some?</a>
              </h4>

            </div>
            <div id="question3" class="panel-collapse collapse in" style="height: auto;">
                <div class="panel-body">
                     <h5><span class="label label-primary">Answer</span></h5>

                    <p>The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other activities. Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room. They respond equally well to the needs of clients in low-income countries.</p>
                </div>
            </div>
        </div>
        
    </div>
	</div>
	</div>
	</div>