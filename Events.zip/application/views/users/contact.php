<div class="container-fluid header-1">
<div class="header-content">
<h1>Contact Us</h1>
<h3><a href="index.html">Home</a> > Contact Us</h3>
</div>
</div>
	
	<div class="container space-top border-rj">
	
	<div class="row">
	<div class="col-md-4">
	<div class=" create-event">
	<h1><i class="fa fa-address-card" aria-hidden="true"></i></h1><h2> &nbsp; &nbsp;  Contact Detail</h2>
	</div>
	<p><span><i class="fa fa-phone" aria-hidden="true"></i><span> &nbsp;   +15145713796 / +15146013882</p>
	<p><span><i class="fa fa-envelope" aria-hidden="true"></i><span> &nbsp;   contact@codticket.com</p>
	</div>
	<div class="col-md-8">
	<div class=" create-event">
	<h1><i class="fa fa-envelope-open-o" aria-hidden="true"></i></h1><h2> &nbsp; &nbsp;  Get In Touch!</h2>
	</div>
    <!-- <form> -->
    <?php $attributes = array('id' => 'mailform');
          echo form_open('user/contactsend', $attributes);?>
		  <div class="form-group">
		    <label for="firstname">NAME</label>
		    <input type="text" class="form-control"  placeholder="Your Name" name="firstname">
		  </div>
		  <div class="form-group">
		    <label for="email">EMAIL</label>
		    <input type="email" class="form-control"  placeholder="Your Email" name="email">
		  </div>
		  <div class="form-group">
		    <label for="phone">PHONE NO.</label>
		    <input type="text" class="form-control"  placeholder="Your Contact Number" name="phone">
		  </div>
		  <div class="form-group">
		    <label for="exampleInputFile">MESSAGE</label>
		    <textarea  class="form-control" rows="4" placeholder="Your Message" name="msg"></textarea>
		  </div>
		  <button type="submit" class="btn btn-outline-primary-2" name="mailaction" value="submit">Submit</button>
    </form>	
	</div>
	</div>
	</div>

	<script type="text/javascript">
        
        $(document).ready(function() {
            $("#mailform").removeAttr("novalidate");
            $("#mailform").validate({
               rules: {
                    firstname: "required",
                    email: {
                      required: true,
                      email: true
                    },
                    phone: "required",
                    msg: "required"
                  },
                messages: {
                    firstname: "Please specify your first name",
                    email: {
                      required: "We need your email address to contact you",
                      email: "Your email address must be in the format of name@domain.com"
                    },
                    phone: "Please specify your phone number",
                    msg: "Please enter your password"
                    
                }

             });
        });

</script>