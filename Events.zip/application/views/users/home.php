<?php 
if($this->session->flashdata('message')!=null){  ?>
<script>
 var msg = "<?php echo $this->session->flashdata('message');?>";
toastr.success(msg);
</script>
<?php } ?>
<div class="container-fluid header">

<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active"><img src="<?php echo base_url()?>assets/images/banner.jpg" alt="codticket"></div>
    <div class="item"><img src="<?php echo base_url()?>assets/images/banner2.jpg" alt="codticket"></div>
	<div class="item"><img src="<?php echo base_url()?>assets/images/banner3.jpg" alt="codticket"></div>
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<!--<img src="<?php echo base_url()?>assets/images/banner.jpg">-->
<div class="banner-content">
<h1>The best Solution For</h1>
<h3>Buying & Selling Tickets</h3>
<p><a href="<?php echo base_url()?>index.php/user/eventcreate" <?php echo $this->session->userdata('frntuser')=='' ? "id=homesignupform" : " "; ?>><button type="button" class="btn btn-outline-primary">Create an Event</button></a> &nbsp; &nbsp; 
<a href="buy-ticket.html"><button type="button" class="btn btn-outline-primary">Buy Ticket</button></a></p>

<form id="search-form">
  <div class="form-group">
    <input type="name" class="form-control-search" id="exampleInputEmail1" placeholder="Event or Categories">
  </div>
  <div class="form-group">
    <input type="email" class="form-control-search" id="exampleInputEmail1" placeholder="City or Location">
  </div>
  <div class="form-group">
    <select name="date" class="form-control-search">
                        <option value="" selected="selected">All Dates</option>
                        <option value="today">Today</option>
                        <option value="tomorrow">Tomorrow</option>
                        <option value="this_week">This Week</option>
                        <option value="this_weekend">This Weekend</option>
                        <option value="next_week">Next Week</option>
                        <option value="next_month">Next Month</option>
     </select>
  </div>
  <a href="discovery-event.html"><button type="submit" class="btn btn-outline-primary-search">Search</button></a>
</form>	
</div>

<div class="container space-top">
	<div class="row">
	<div class="col-md-4 ticket">
	<i class="fa fa-check-circle" aria-hidden="true"></i>
	<h3>Choose Event and Ticket</h3>
	<p>with only a few click</p>
	</div>
	<div class="col-md-4 ticket">
	<i class="fa fa-shopping-cart" aria-hidden="true"></i>
	<h3>Buy Directly From Organizers</h3>
	<p>pay online or cash on delivery</p>
	</div>
	<div class="col-md-4 ticket">
	<i class="fa fa-ticket" aria-hidden="true"></i>
	<h3>Receive Tickets</h3>
	<p>via email or right at your door</p>
	</div>
	</div>		
	</div>
</div>
	
	<div class="container space-top border-rj">
	<div class="row">
    <div class="col-md-6">
	<img src="<?php echo base_url()?>assets/images/event.jpg">
	</div>
    <div class="col-md-6">
	<div class="event">
	<h1>Disco Dance <strong>$50+</strong></h1>
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i> 300/100<span> &nbsp; 
	<span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span> &nbsp; 
	<span><i class="fa fa-map-marker" aria-hidden="true"></i> 300/100<span></p>
	</div>
	<div class="event-block">
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets! We take care of creating and validating tickets on the day of the show. Our ticketing system is computerized, innovative and safe.</p>
	
	<div class="timer-counter-date">
	<table border="0" cellpadding="0" cellspacing="0" style="margin:0 auto;" class="p"><tbody><tr class="cr"><td id="cd">3</td><td>:</td><td id="ch">18</td><td>:</td><td id="cm">55</td><td>:</td><td id="cs">52</td></tr><tr class="cl"><td id="ld">Day(s)</td><td></td><td id="lh">Hour(s)</td><td></td><td id="lm">Minute(s)</td><td></td><td id="ls">Second(s)</td></tr></tbody></table>
	</div>
	</div>	
	<a href="buy-ticket.html"><button type="button" class="btn btn-outline-primary-1">Buy Ticket</button></a>
	</div>
    </div>	
	</div>
	
	<div class="container space-top-1 border-rj-1">
	<h1 class="heading"><span><i class="fa fa-calendar" aria-hidden="true"></i></span> &nbsp; Upcoming Event  <strong><a href="discovery-event.html">View More</a></strong></h1>
	<div class="row">
    <div class="col-md-6">
	<div class="event-img">
	<img src="<?php echo base_url()?>assets/images/event-1.jpg">
	<div class="timer-counter-date-1">
	<table border="0" cellpadding="0" cellspacing="0" style="margin:0 auto;" class="p"><tbody><tr class="cr"><td id="cd">30</td><td>:</td><td id="ch">19</td></tr><tr class="cl"><td id="ld">Days</td><td></td><td id="lh">Hrs</td></tr></tbody></table>
	</div>
	<div class="layer">
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i> 300/100 Tickets<span> &nbsp; 
	<span style="float:right;"><i class="fa fa-map-marker" aria-hidden="true"></i> Harlansburg, United States<span></p></div>
	</div>
	<div class="event-2" style="margin-top: -39px;">
	<h1>Disco Dance <strong>$50+</strong></h1>
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i> 300/100<span> &nbsp; 
	<span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span> &nbsp; 
	<span><i class="fa fa-map-marker" aria-hidden="true"></i> 300/100<span></p>
	</div>
	</div>
    <div class="col-md-6">
	<div class="event-img">
	<img src="<?php echo base_url()?>assets/images/event-2.jpg">
	<div class="timer-counter-date-1">
	<table border="0" cellpadding="0" cellspacing="0" style="margin:0 auto;" class="p"><tbody><tr class="cr"><td id="cd">30</td><td>:</td><td id="ch">19</td></tr><tr class="cl"><td id="ld">Days</td><td></td><td id="lh">Hrs</td></tr></tbody></table>
	</div>
	<div class="layer">
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i> 300/100 Tickets<span> &nbsp; 
	<span style="float:right;"><i class="fa fa-map-marker" aria-hidden="true"></i> Harlansburg, United States<span></p></div>
	</div>
	<div class="event-2" style="margin-top: -39px;">
	<h1>Disco Dance <strong>$50+</strong></h1>
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i> 300/100<span> &nbsp; 
	<span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span> &nbsp; 
	<span><i class="fa fa-map-marker" aria-hidden="true"></i> 300/100<span></p>
	</div>
	</div>
    </div>	
	</div>
	
	<div class="container space-top-1 border-rj">
	<h1 class="heading"><span><i class="fa fa-calendar" aria-hidden="true"></i></span> &nbsp; Feature Event  <strong><a href="discovery-event.html">View More</a></strong></h1>
	<div class="row">
    <div class="col-md-4">
	<div class="event-img">
	<div class="date"><p><b>30</b></br>JUN</p></div>
	<img src="<?php echo base_url()?>assets/images/event-1.jpg">
	</div>
	<div class="event-2">
	<h1>Disco Dance <strong>$50+</strong></h1>
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i> 300/100<span> &nbsp; 
	<span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span> &nbsp; 
	<span><i class="fa fa-map-marker" aria-hidden="true"></i> 300/100<span></p>
	</div>
	</div>
    <div class="col-md-4">
	<div class="event-img">
	<div class="date"><p><b>30</b></br>JUN</p></div>
	<img src="<?php echo base_url()?>assets/images/event-2.jpg">
	</div>
	<div class="event-2">
	<h1>Disco Dance <strong>$50+</strong></h1>
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i> 300/100<span> &nbsp; 
	<span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span> &nbsp; 
	<span><i class="fa fa-map-marker" aria-hidden="true"></i> 300/100<span></p>
	</div>
	</div>
	<div class="col-md-4">
	<div class="event-img">
	<div class="date"><p><b>30</b></br>JUN</p></div>
	<img src="<?php echo base_url()?>assets/images/event-2.jpg">
	</div>
	<div class="event-2">
	<h1>Disco Dance <strong>$50+</strong></h1>
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i> 300/100<span> &nbsp; 
	<span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span> &nbsp; 
	<span><i class="fa fa-map-marker" aria-hidden="true"></i> 300/100<span></p>
	</div>
	</div>
	<div class="col-md-12 button-rj">
	<p>Not your interested? &nbsp; &nbsp;   <a href="discovery-event.html"><button type="button" class="btn btn-outline-primary-1">Discovery Events</button></a></p>
	</div>
	
    </div>	
	</div>
	
	<section id="carousel">
		<div class="container">
	<div>
  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#sold" aria-controls="sold" role="tab" data-toggle="tab">
	<b>101K</b></br>Tickets Sold</a></li>
    <li role="presentation"><a href="#customer" aria-controls="customer" role="tab" data-toggle="tab">
	<b>75K</b></br>Great Customer</a></li>
    <li role="presentation"><a href="#client" aria-controls="client" role="tab" data-toggle="tab">
	<b>350K</b></br>Happy Clients</a></li>
    <li role="presentation"><a href="#partner" aria-controls="partner" role="tab" data-toggle="tab">
	<b>200K</b></br>Partner</a></li>
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="sold">
	<h1 class="heading" style="text-align:center;">We have what you need!</h1>
	<div class="row">
    <div class="col-md-6">
	<img src="<?php echo base_url()?>assets/images/event.jpg">
	</div>
    <div class="col-md-6">
	<div class="row" style="border-bottom: 1px solid #fff;margin-bottom: 10px;">
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    </div>
	<div class="row">
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    </div>
	</div>
    </div>
	</div>
	
    <div role="tabpanel" class="tab-pane" id="customer">
	<h1 class="heading" style="text-align:center;">We have what you need!</h1>
	<div class="row">
    <div class="col-md-6">
	<div class="row" style="border-bottom: 1px solid #fff;margin-bottom: 10px;">
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    </div>
	<div class="row">
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    </div>
	</div>
    <div class="col-md-6">
	<img src="<?php echo base_url()?>assets/images/event.jpg">
	</div>
    </div>
	</div>
	
    <div role="tabpanel" class="tab-pane" id="client">
	<h1 class="heading" style="text-align:center;">We have what you need!</h1>
	<div class="row">
    <div class="col-md-6">
	<img src="<?php echo base_url()?>assets/images/event.jpg">
	</div>
    <div class="col-md-6">
	<div class="row" style="border-bottom: 1px solid #fff;margin-bottom: 10px;">
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    </div>
	<div class="row">
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    </div>
	</div>
    </div>
	</div>
	
    <div role="tabpanel" class="tab-pane" id="partner">
	<h1 class="heading" style="text-align:center;">We have what you need!</h1>
	<div class="row">
    <div class="col-md-6">
	<div class="row" style="border-bottom: 1px solid #fff;margin-bottom: 10px;">
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    </div>
	<div class="row">
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    <div class="col-md-6">
	<span><i class="fa fa-flag" aria-hidden="true"></i><span>
	<h4>Create Event Easily</h4>
	<p>You organize a concert, a sporting event or any show ... order at CodTicket ™ unique and tamper-proof tickets!</p>
	</div>
    </div>
	</div>
    <div class="col-md-6">
	<img src="<?php echo base_url()?>assets/images/event.jpg">
	</div>
    </div>
	</div>
  </div>
			</div>
		</div>
	</section>
	
	<div class="container space-top-1">
	<h1 class="heading" style="text-align:center;">What Our Clients Say</h1>
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class="carousel slide" id="fade-quote-carousel" data-ride="carousel" data-interval="3000">
				  <!-- Carousel indicators -->
                  <ol class="carousel-indicators">
				    <li data-target="#fade-quote-carousel" data-slide-to="0" class="active"></li>
				    <li data-target="#fade-quote-carousel" data-slide-to="1"></li>
				    <li data-target="#fade-quote-carousel" data-slide-to="2"></li>
				  </ol>
				  <!-- Carousel items -->
				  <div class="carousel-inner">
				    <div class="active item">
                        <div class="profile-circle" style="background-color: rgba(0,0,0,.2);"><img src="<?php echo base_url()?>assets/images/test-1.png"></div>
				    	<blockquote>
				    		<p>Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room.</p>
							<p><b>Alex Bonchenky</b> &nbsp; &nbsp; <b style="color: #09c;">CEO Glove Pvt. Ltd.</b></p>
				    	</blockquote>	
				    </div>
					<div class="item">
                        <div class="profile-circle" style="background-color: rgba(0,0,0,.2);"><img src="<?php echo base_url()?>assets/images/test-1.png"></div>
				    	<blockquote>
				    		<p>Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room.</p>
							<p><b>Alex Bonchenky</b> &nbsp; &nbsp; <b style="color: #09c;">CEO Glove Pvt. Ltd.</b></p>
				    	</blockquote>	
				    </div>
					<div class="item">
                        <div class="profile-circle" style="background-color: rgba(0,0,0,.2);"><img src="<?php echo base_url()?>assets/images/test-1.png"></div>
				    	<blockquote>
				    		<p>Our activities are characterized by the production of tickets integrating unique codes and the provision of equipment allowing the validation of tickets and The real-time monitoring of the filling process of the room.</p>
							<p><b>Alex Bonchenky</b> &nbsp; &nbsp; <b style="color: #09c;">CEO Glove Pvt. Ltd.</b></p>
				    	</blockquote>	
				    </div>
				  </div>
				</div>
			</div>							
		</div>
	</div>
	
  <script type="text/javascript">
	$(document).ready(function(){
	         $('#homesignupform').click(function(){
	         $("#homesignupform").removeAttr("href").css("cursor","pointer");
	         $('#loginmodel').modal('show');
                });
	});
   </script>