<?php
if ($this->session->userdata('userrole') !== 'promoter') {
    redirect('user/do_login');
}
if ($this->session->flashdata('message') != null) {
    ?>
    <script>
        var msg = "<?php echo $this->session->flashdata('message'); ?>";
        toastr.success(msg);
    </script>
<?php } ?>
<div class="container-fluid header-1">
    <div class="header-content">
        <h1>Create Event</h1>
        <h3><a href="<?php echo base_url()?>">Home</a> > Create Event</h3>
    </div>
</div>

<div class="container space-top border-rj">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class=" create-event">
                <h1>1</h1><h2> &nbsp; &nbsp;  Event Detail</h2>
            </div>
            <!-- <form> -->
<?php
$attribute = array('name' => 'eventForm', 'id' => 'eventForm', 'enctype' => 'multipart/form-data');
echo form_open('user/saveEvent', $attribute);
?>
            <div class="form-group">
                <label for="eventtitle">EVENT TITLE</label>
                <input type="text" class="form-control" id="eventtitle" placeholder="Give it a short distinct name" name="eventtitle">
            </div>

            <div class="form-group">
                <label for="location">LOCATION</label>
                <input type="text" class="form-control" id="location" placeholder="Specify where it's held" name="location">
                    <!--<span><a href="#"><i class="fa fa-laptop" aria-hidden="true"></i> Online Event</a></span> 
                    <span><a href="#"><i class="fa fa-laptop" aria-hidden="true"></i> Enter Address</a></span>-->
            </div>

            <div class="form-group">
                <div class="row">
                    <div class="col-md-6 col-pad-2">
                        <label for="startDate">START DATE</label>
                        <input type="text" class="form-control" id="datetimepicker1" placeholder="Select date" name="startDate">
                    </div>
                    <div class="col-md-6 col-pad-2">
                        <label for="location">END DATE</label>
                        <input type="text" class="form-control" id="datetimepicker2" placeholder="Select date" name="endDate">
                    </div>  </div> 
            </div>

            <div class="form-group">
                <label for="eventImage">EVENT IMAGE</label>
                <input type="file" id="file" name="eventImage">
                <p class="help-block">We recommend using at least a 690x600px image that's no larger than 1MB. <a href="<?php echo base_url() ?>index.php/user/learnmore" target="_blank">Learn more</a>.</p>
            </div>

            <div class="form-group">
                <label for="eventDescription">EVENT DESCRIPTION</label>
                <textarea type="message" class="form-control" rows="8" placeholder="Event Description" name="eventDescription"></textarea>
                <span><a href="<?php echo base_url() ?>index.php/user/faq" target="_blank">Add FAQs</a></span> 
            </div>

            <div class="form-group">
                <label for="organiserName">ORGANISER NAME</label>
                <input type="text" class="form-control" id="organiserName" placeholder="Who's organising this event?" name="organiserName">
            </div>

            <div class="form-group">
                <label for="organiserDescription">ORGANISER DESCRIPTION</label>
                <textarea type="message" class="form-control" rows="8" placeholder="Organiser Description" name="organiserDescription"></textarea>
                <span><a href="<?php echo base_url() ?>index.php/user/faq" target="_blank">Add FAQs</a></span> 
            </div>

            <div class="form-group">
                <label for="organiserImage">ORGANISER IMAGE</label>
                <input type="file" id="file" name="organiserImage">
                <p class="help-block">We recommend using at least a 500x500px image that's no larger than 1MB. <a href="learn-more.html">Learn more</a>.</p>
            </div>

            <div style="margin-bottom:30px;">
                <div class="checkbox">
                    <label data-toggle="collapse" data-target="#collapseOne">
                        <input type="checkbox"> Link to Facebook and Twitter
                    </label>
                </div>
                <div id="collapseOne" class="panel-collapse collapse in">
                    <div class="form-group">
                        <label for="facebook">Facebook Link</label>
                        <input type="text" class="form-control" id="text" placeholder="Enter Facebook Link" name="facebook">
                    </div>
                    <div class="form-group">
                        <label for="twitter">Twitter Link</label>
                        <input type="text" class="form-control" id="text" placeholder="Enter Twitter Link" name="twitter">
                    </div>
                </div>   </div>


            <div class=" create-event">
                <h1>2</h1><h2> &nbsp; &nbsp;  Additional Settings</h2>
            </div>

            <div class="form-group">
                <label for="floorImage">ADD FLOOR PLAN IMAGE</label>
                <input type="file" id="filefloor" name="floorImage">
                <p class="help-block">We recommend using at least a 1200x800px image that's no larger than 1MB. <a href="learn-more.html">Learn more</a>.</p>
                <img src="<?php echo base_url() ?>assets/images/floorplan.png">
            </div>

            <div class="form-group">
                <label for="eventtype">EVENT TYPE </label>
                <select class="form-control" onchange="neweventtype(this.value)" name="eventtype">
                    <option value="" selected="selected">Select the type of event</option>
                    <option value="Appearance or Signing">Appearance or Signing</option>
                    <option value="Attraction">Attraction</option>
                    <option value="Camp, Trip or Retreat">Camp, Trip or Retreat</option>
                    <option value="Concert or Performance">Concert or Performance</option>
                    <option value="5">Conference</option>
                    <option value="Conference">Convention</option>
                    <option value="Course, Training or Workshop">Course, Training or Workshop</option>
                    <option value="Dinner or Gala">Dinner or Gala</option>
                    <option value="Festival or Fair">Festival or Fair</option>
                    <option value="Game or Competition">Game or Competition</option>
                    <option value="Meeting or Networking Event">Meeting or Networking Event</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="form-group" style="display:none" id="otherevent">
                <input type="text" class="form-control" id="text" placeholder="Other Event Type" name="otherEventType">
            </div>

            <div class="form-group">
                <label for="eventTopic">EVENT TOPIC</label>
                <select class="form-control" onchange="neweventtopic(this.value)" name="eventTopic">
                    <option value="" selected="selected">Select a topic</option>
                    <option value="Business Professional">Business Professional</option>
                    <option value="Charities Causes">Charities Causes</option>
                    <option value="Community Culture">Community Culture</option>
                    <option value="Family Education">Family Education</option>
                    <option value="Fashion Beauty">Fashion Beauty</option>
                    <option value="Film, Media Entertainment">Film, Media Entertainment</option>
                    <option value="Food Drink">Food Drink</option>
                    <option value="Government Politics">Government Politics</option>
                    <option value="Health Wellness">Health Wellness</option>
                    <option value="Music">Music</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="form-group" style="display:none" id="othertopic">
                <input type="text" class="form-control" id="text" placeholder="Other Event Type" name="otherEventTopic">
            </div>

            <div class="form-group">
                <label for="eventtitle">TERMS AND CONDITIONS</label>
                <div class="checkbox">
                    <label>
                        <input type="checkbox"> I have read and agree to the Privacy Policy
                    </label>
                </div>
            </div>
            <p style="text-align:center;">
                <button type="submit" class="btn btn-outline-primary-rj">Make Your Event Live</button> &nbsp; &nbsp; 
               <!--<A href="<?php echo base_url() ?>index.php/user/createTicket"><button type="button" class="btn btn-outline-primary-rj">Create Ticket</button></a>-->
            </p>
            </form>	
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#datetimepicker1').datetimepicker({
        format: 'Y-m-d H:i',
    });
    $('#datetimepicker2').datetimepicker({
        format: 'Y-m-d H:i',
    });

    function neweventtype(type) {
        if (type == 'Other') {
            $('#otherevent').show();
        } else {
            $('#otherevent').hide();
        }
    }

    function neweventtopic(type) {
        if (type == 'Other') {
            $('#othertopic').show();
        } else {
            $('#othertopic').hide();
        }
    }
    $(document).ready(function () {
        $("#eventForm").removeAttr("novalidate");
        $("#eventForm").validate({
            rules: {
                eventtitle: "required",
                location: "required",
                startDate: "required",
                endDate: "required",
                eventDescription: "required",
                organiserName: "required",
                organiserDescription: "required",
                eventtype: "required",
                eventTopic: "required",
                eventImage: "required",
                organiserImage: "required",
                organiserImage: "required"
            },
            messages: {
                eventtitle: "Please specify Event Title",
                location: "Please specify Event location",
                startDate: "Please specify Event Start date",
                endDate: "Please specify Event End date",
                eventDescription: "Please specify Event description",
                organiserName: "Please specify Event organiser name",
                organiserDescription: "Please specify Event organisation description",
                eventtype: "Please specify Event type",
                eventTopic: "Please specify Event topic",
                eventImage: "Please specify Event image",
                organiserImage: "Please specify Event organiser image",
                floorImage: "Please specify Event floor plan image",
            }

        });
    });
</script>

