<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class CodEvent extends CI_Model {

    CONST EVENT_TABLE = 'events';
    CONST EVENT_PRIMARY = 'event_id';

    public function register($val) {

        $num = $this->db->insert(self::EVENT_TABLE, $val);
        if ($num) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

}
