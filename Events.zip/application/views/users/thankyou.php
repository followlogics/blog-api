<div class="container-fluid header-1">
<div class="header-content">
<h1>Thank You</h1>
<h3><a href="index.html">Home</a> > Thank You</h3>
</div>
</div>
	
	<div class="container space-top border-rj">
	<div class="row">
    <div class="col-md-10 col-md-offset-1 thanku">
	 <h1>Thank You</h1>
	<h4><?php echo $this->session->flashdata('item'); ?> </h4>
	<!-- <h4>A representative will be in touch very Soon!!!</h4> -->
	</div>
    </div>	
	</div>