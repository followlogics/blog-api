<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->helper(array('cookie'));

        $this->load->model('m_user');
        $lang = $this->session->get_userdata('language');
        if (!(isset($lang) && $lang)) {
            $lang = 'english';
        }
        $this->lang->load('all_text', $lang);
    }

    public function index() {

        $this->load->view('template/header');

        $this->load->view('users/home');

        $this->load->view('template/footer');
    }

    public function do_signup() {
        if ($this->input->post('action') == 'submit') {

            if ($this->form_validation->run() == true) {
                if ($this->input->post('userrole') == 'buyer') {
                    $actives = 'ok';
                } else {
                    $actives = 'ok';
                }
                $hash = md5(rand(0, 1000));

                $data['user_role'] = $this->input->post('userrole');

                $data['first_name'] = $this->input->post('firstname');

                $data['last_name'] = $this->input->post('lastname');

                $data['phone_number'] = $this->input->post('phone');

                $data['email'] = $this->input->post('email');

                $data['password'] = md5($this->input->post('password'));

                $data['status'] = $actives;

                $data['email_verification'] = $hash;

                $confirm = $this->m_user->register($data);

                if ($confirm) {
                    $config = Array(
                        'protocol' => 'smtp',
                        'smtp_host' => 'ssl://smtp.googlemail.com',
                        'smtp_port' => 465,
                        'smtp_user' => '',
                        'smtp_pass' => '',
                        'mailtype' => 'html',
                        'charset' => 'iso-8859-1'
                    );
                    $hash = md5(rand(0, 1000));
                    $this->load->library('email', $config);
                    $this->email->set_newline("\r\n");
                    $this->email->initialize($config);

                    $this->email->from('info@codticket.com', 'Codticket');
                    $this->email->to($this->input->post('email'));

                    $this->email->subject('Account Detail of Codticket');
                    $msg = "Hi " . $this->input->post('firstname') . ",\r\n Thank you for registration your username is " . $this->input->post('email') . " and password is " . $this->input->post('password') . ",\r\n Please click this link to activate your account: ,\r\n" . base_url() . 'index.php/user/verify?' .
                            'email=' . $this->input->post('email') . '&hash=' . $hash;
                    $this->email->message($msg);
                    $this->email->send();
                    $this->session->set_flashdata('item', 'Your Registration has been successfully submitted to us.');
                    redirect('user/thankyou');
                    /* $page_data['page_title'] = "registration";

                      $this->load->view('template/header');

                      $this->load->view('users/thankyou',$page_data);

                      $this->load->view('template/footer'); */
                }
            }
        }

        $this->load->view('template/header');
        $this->load->view('users/signup');
        $this->load->view('template/footer');
    }

    public function thankyou() {
        $this->load->view('template/header');

        $this->load->view('users/thankyou');

        $this->load->view('template/footer');
    }

    public function do_login() {
        if ($this->input->post('loginbt') == 'submit') {

            if ($this->form_validation->run() == true) {
                $username = $this->input->post('username');
                $password = $this->input->post('password');

                $loginSucess = $this->m_user->loginsucess($username, $password);

                if ($loginSucess) {
                    redirect('user/index');
                } else {

                    $this->session->set_flashdata('item', array('message' => 'Your User name and Password do not match', 'class' => 'errormsg'));
                }
            }
        }
        $this->load->view('template/header');
        $this->load->view('users/login');
        $this->load->view('template/footer');
    }

    public function do_Modellogin() {
        //echo 'ajay';
        //print_r($_POST);
        $username = $this->input->post('mdUsername');
        $password = $this->input->post('mdPassword');
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('email', $username);
        $this->db->where('user_role', 'promoter');
        $this->db->where('password', MD5($password));
        $this->db->where('status', 'ok');
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {     //echo "fdshgfhgds fdsgfh dshf dfghjd f ";
            $userinfo = $query->result_array();
            $this->session->set_userdata('user_id', $userinfo[0]['user_id']);
            $this->session->set_userdata('fname', $userinfo[0]['first_name']);
            $this->session->set_userdata('lname', $userinfo[0]['last_name']);
            $this->session->set_userdata('emailid', $userinfo[0]['email']);
            $this->session->set_userdata('frntuser', 'yes');
            $this->session->set_userdata('userrole', $userinfo[0]['user_role']);
            if ($this->input->post('remember')) {
                $login_name = array(
                    'name' => 'login_name',
                    'value' => $para1,
                    'expire' => time() + 365 * 24 * 60 * 5,
                    'path' => '/',
                    'prefix' => 'lg_',
                );
                $login_password = array(
                    'name' => 'login_password',
                    'value' => $para2,
                    'expire' => time() + 365 * 24 * 60 * 5,
                    'path' => '/',
                    'prefix' => 'lg_',
                );
                //echo "test";
                set_cookie($login_name);
                set_cookie($login_password);
            }
            $this->session->set_flashdata('item', 'Your enquiry has been successfully submitted to us. A representative will be in touch very Soon!!!');

            echo 'OK';
        } else {

            $auth_error = '<div id="notification_error">The login info is not correct.</div>';

            echo $auth_error;
        }
    }

    public function forget() {
        $this->load->view('template/header');
        $this->load->view('users/forgetPage');
        $this->load->view('template/footer');
    }

    public function aboutPage() {
        $this->load->view('template/header');
        $this->load->view('users/about');
        $this->load->view('template/footer');
    }

    public function discoveryEvent() {
        
        $this->load->view('template/header');
        $this->load->view('users/discovery_event');
        $this->load->view('template/footer');
    }

    public function ourSolutions() {
        $this->load->view('template/header');
        $this->load->view('users/our_solutions');
        $this->load->view('template/footer');
    }

    public function eventcreate() {
        $this->load->view('template/header');
        $this->load->view('users/eventCreate');
        $this->load->view('template/footer');
    }

    public function verify() {
        $email = $_GET['email'];
        $hash = $_GET['hash'];
        $query = $this->db->get_where('users', array('email' => $email));
        if ($query->num_rows() > 0) {
            $ret = $query->row();
            $val_hash = $ret->email_verification;
            if ($val_hash == $hash) {
                $data = array(
                    'status' => 'ok',
                    'email_verification' => ''
                );

                $this->db->where('email', $email);
                $this->db->update('users', $data);
                $this->load->view('template/header');
                $this->load->view('users/home');
                $this->load->view('template/footer');
            }
        }
    }

    public function contactus() {
        $this->load->view('template/header');
        $this->load->view('users/contact');
        $this->load->view('template/footer');
    }

    public function logout() {
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('fname');
        $this->session->unset_userdata('lname');
        $this->session->unset_userdata('emailid');
        $this->session->unset_userdata('frntuser');
        $this->session->unset_userdata('userrole');

        redirect('user/index');
    }

    public function buyerProfile($para1 = '') {
        if (!(($this->session->userdata('userrole')) && ($this->session->userdata('userrole') == 'buyer'))) {
            redirect(base_url());
            exit;
        }
        if ($para1 == 'update') {

            if ($this->input->post('action') == 'submit') {

                echo $userid = $this->session->userdata('user_id');

                $data['name_prefix'] = $this->input->post('name_pre');

                $data['first_name'] = $this->input->post('firstname');

                $data['last_name'] = $this->input->post('lastname');

                $data['phone_number'] = $this->input->post('phonenumber');

                $data['email'] = $this->input->post('email');

                $data['home_address'] = $this->input->post('home_add');

                $data['office_address'] = $this->input->post('office_add');

                $data['gender'] = $this->input->post('gender');

                $data['date_of_birth'] = $this->input->post('dob');

                $buyeredit = $this->m_user->edit_buyerinfo($data, $userid);

                if ($buyeredit) {
                    redirect('user/buyerProfile');
                }
            }
        } else {
            $data['proter'] = $this->m_user->get_buyerinfo();
            $this->load->view('template/header');
            $this->load->view('users/buyer_profile', $data);
            $this->load->view('template/footer');
        }
    }

    public function promoterProfile($para1 = '') {

        if (!(($this->session->userdata('userrole')) && ($this->session->userdata('userrole') == 'promoter'))) {
            redirect(base_url());
            exit;
        }
        if ($para1 == 'update') {

            if ($this->input->post('action3') == 'submit') {

                $userid = $this->session->userdata('user_id');

                $data['name_prefix'] = $this->input->post('name_pre');

                $data['first_name'] = $this->input->post('firstname');

                $data['last_name'] = $this->input->post('lastname');

                $data['phone_number'] = $this->input->post('phonenumber');

                $data['email'] = $this->input->post('email');

                $data['home_address'] = $this->input->post('home_add');

                $data['office_address'] = $this->input->post('office_add');

                $data['gender'] = $this->input->post('gender');

                $data['date_of_birth'] = $this->input->post('dob');

                $promoteredit = $this->m_user->edit_promoterinfo($data, $userid);

                if ($promoteredit) {

                    redirect('user/promoterProfile');
                }
            }
        } else {

            $data['proter'] = $this->m_user->get_promoterinfo();
            $this->load->view('template/header');
            $this->load->view('users/promoter_profile', $data);
            $this->load->view('template/footer');
        }
    }

    public function buyerbilling() {
        if ($this->input->post('action2') == 'submit') {

            $userid = $this->session->userdata('user_id');

            $data['billing_phone'] = $this->input->post('billing_phone');

            $data['billing_email'] = $this->input->post('billing_email');

            $data['bank_name'] = $this->input->post('bank_name');

            $data['bank_account_number'] = $this->input->post('bank_account_number');

            $data['billing_street1'] = $this->input->post('billing_street1');

            $data['billing_street2'] = $this->input->post('billing_street2');

            $data['country'] = $this->input->post('country');

            $data['state'] = $this->input->post('state');

            $data['billing_city'] = $this->input->post('billing_city');

            $data['billing_postelcode'] = $this->input->post('billing_postelcode');

            //print_r($data);die;

            $promoteredit = $this->m_user->edit_buyerinfo($data, $userid);

            if ($promoteredit) {

                redirect('user/buyerProfile');
            }
        }
    }

    public function promoterbilling() {
        if ($this->input->post('action3') == 'submit') {

            $userid = $this->session->userdata('user_id');

            $data['billing_phone'] = $this->input->post('billing_phone');

            $data['billing_email'] = $this->input->post('billing_email');

            $data['bank_name'] = $this->input->post('bank_name');

            $data['bank_account_number'] = $this->input->post('bank_account_number');

            $data['billing_street1'] = $this->input->post('billing_street1');

            $data['billing_street2'] = $this->input->post('billing_street2');

            $data['country'] = $this->input->post('country');

            $data['state'] = $this->input->post('state');

            $data['billing_city'] = $this->input->post('billing_city');

            $data['billing_postelcode'] = $this->input->post('billing_postelcode');

            //print_r($data);die;

            $promoteredit = $this->m_user->edit_promoterinfo($data, $userid);

            if ($promoteredit) {

                redirect('user/promoterProfile');
            }
        }
    }

    public function profilepic() {
        //print_r($_FILES);die;
        $image = '';
        $config['upload_path'] = './assets/images/avatar/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 100;
        $config['max_width'] = 1024;
        $config['max_height'] = 768;
        $this->load->library('upload');
        $this->upload->initialize($config);
        if (!$this->upload->do_upload('image_src')) {
            $error = array('error' => $this->upload->display_errors());
        } else {
            $data = array('upload_data' => $this->upload->data());
            $image = $this->upload->file_name;
            echo $image;
            die();
        }
    }

    public function createTicket() {
        $this->load->view('template/header');
        $this->load->view('users/ticketCreate');
        $this->load->view('template/footer');
    }

    public function faq() {
        $this->load->view('template/header');
        $this->load->view('users/faq');
        $this->load->view('template/footer');
    }

    public function learnmore() {
        $this->load->view('template/header');
        $this->load->view('users/learnmore');
        $this->load->view('template/footer');
    }

    public function contactsend() {
        if ($this->input->post('mailaction') == 'submit') {
            $this->email->from('contact@codticket.com', 'Codticket');
            $this->email->to($this->input->post('email'));
            $this->email->subject('Enqury form for contact@codticket.com');
            $msg = " Email : " . $this->input->post('email') . ",\r\n Contact number : " . $this->input->post('phone') . ",\r\n Message : " . $this->input->post('msg');
            $this->email->message($msg);
            $this->email->send();
            $this->session->set_flashdata('message', 'Your enquiry has been successfully submitted to us. A representative will be in touch very Soon!!!');
            redirect('user/index');
        }
    }

    public function resetpassword() {
        $this->load->view('template/header');
        $this->load->view('users/resetpassword');
        $this->load->view('template/footer');
    }

    public function sendforgetmail() {
        if ($this->input->post('actionForget')) {
            //print_r($_POST);die;
            $this->email->from('contact@codticket.com', 'Codticket');
            $this->email->to($this->input->post('email'));
            $this->email->subject('Plz click here goto reset your password');
            $msg = " Hi " . $this->session->userdata('fname') . ",\r\n Please click this link to activate your account: ,\r\n" . base_url() . "index.php/user/resetpassword?" .
                    "email=" . $this->input->post('email');
            $this->email->message($msg);
            $this->email->send();
            echo '<div class="container space-top border-rj">
                <div class="row">
                <div class="col-md-10 col-md-offset-1 thanku">
                <h1>Thank You</h1>
                <h4>Your Reset password link send to your register email.</h4>
                <h4>click link and reset your passowrd!!!</h4>
                </div>
                </div>  
                </div>';
        }
    }

    public function passwordUpdate() {
        $password = $this->input->post('password');
        $email = $this->input->post('email');
        $confirmchange = $this->m_user->confirmchangePassword($password, $email);
        if ($confirmchange) {
            $this->email->from('contact@codticket.com', 'Codticket');
            $this->email->to($email);
            $this->email->subject('Plz click here goto reset your password');
            $msg = " Hi Your password change successfully \r\n your new password is: \r\n" . $password;
            "email=" . $this->input->post('email');
            $this->email->message($msg);
            $this->email->send();
            $this->session->set_flashdata('message', 'Your password change successfully !!!');

            redirect('user/index');
        }
    }

    public function saveEvent() {
        
        $data = array(
            'event_title' => $this->input->post('eventtitle'),
            'event_location' => $this->input->post('location'),
            'event_startdate' => $this->input->post('startDate'),
            'event_enddate' => $this->input->post('endDate'),
            'event_description' => $this->input->post('eventDescription'),
            'event_organiser_name' => $this->input->post('organiserName'),
            'event_organiser_description' => $this->input->post('organiserDescription'),
            'event_organiser_facebook' => $this->input->post('facebook'),
            'event_organiser_twitter' => $this->input->post('twitter'),
            'event_type' => $this->input->post('eventtype'),
            'otherEventType' => $this->input->post('otherEventType'),
            'event_topic' => $this->input->post('eventTopic'),
            'otherEventTopic' => $this->input->post('otherEventTopic'),
            'event_image' => $_FILES['eventImage']['name'],
            'event_organiser_image' => $_FILES['organiserImage']['name'],
            'event_floorplan_image' => $_FILES['floorImage']['name'],
            'event_status' => 'deactive'
        );
        $config['upload_path'] = 'assets/images/eventimage';
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = '5000';
        $this->load->library('upload', $config);
        $numcot = count($_FILES);

        foreach ($_FILES as $field => $value) {
            if (!$this->upload->do_upload($field)) {
                echo $this->upload->display_errors();
            } else {
                $file_data = $this->upload->data();
                //print_r($this->upload->data()); 
            }
        }
        if ($this->db->insert('events', $data)) {
            $insert_id = $this->db->insert_id();
            $this->session->set_flashdata('message', 'Your event has been created successfully...');
            redirect('user/eventSuccess/' . $insert_id);
        } else {
            $this->session->set_flashdata('message', 'Sory event has been created plz try again...');
            redirect('user/eventcreate');
        }
    }

    public function eventSuccess() {
        $this->load->view('template/header');
        $this->load->view('users/eventSuccess');
        $this->load->view('template/footer');
    }

}
