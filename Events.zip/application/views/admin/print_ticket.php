<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Print Ticket Order</h1>
      <ol class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Print Ticket Order</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title" style="margin: 8px 0px;">Print Ticket Order Listing</h3>
			  <a href="generate-ticket.html"><button style="float: right" type="button" class="btn btn-primary"> Process and Generate Ticket</button></a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped table-responsive">
                <thead>
                <tr>
				  <th>Ticket Number</th>
                  <th>Event Title</th>
				  <th>Ticket Type</th>
                  <th>No. of Ticket</th>
                  <th>Price per Ticket</th>
				  <th>Mode of Ticket</th>
                  <th>Promoter Name</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>10020</td>
				  <td>Spiritual Adventure</td>
                  <td>General Ticket</td>
				  <td>200</td>
                  <td>$100</td>
				  <td>Offline</td>
                  <td>Integer Amet Fames</td>
                  <td><a href="<?php echo base_url()?>index.php/admin/printTicketView"><button type="button" class="btn btn-success action-btn" title="View More"><i class="fa fa-eye"></i></button></a>
				  <a href="<?php echo base_url()?>index.php/admin/printTicketEdit"><button type="button" class="btn btn-warning action-btn" title="Edit"><i class="fa fa-pencil-square-o"></i></button></a>
				  <a href="#delete"><button type="button" class="btn btn-danger action-btn" title="Delete"><i class="fa fa-trash-o"></i></button></a></td>
                </tr>
				<tr>
                  <td>10021</td>
				  <td>Spiritual Adventure</td>
                  <td>VIP Ticket</td>
				  <td>500</td>
                  <td>$150</td>
				  <td>Offline</td>
                  <td>Integer Amet Fames</td>
                  <td><a href="print-ticket-view.html"><button type="button" class="btn btn-success action-btn" title="View More"><i class="fa fa-eye"></i></button></a>
				  <a href="print-ticket-edit.html"><button type="button" class="btn btn-warning action-btn" title="Edit"><i class="fa fa-pencil-square-o"></i></button></a>
				  <a href="#delete"><button type="button" class="btn btn-danger action-btn" title="Delete"><i class="fa fa-trash-o"></i></button></a></td>
                </tr>
                </tbody>
                <tfoot>
                <tr>
                  <th>Ticket Number</th>
				  <th>Event Title</th>
				  <th>Ticket Type</th>
                  <th>No. of Ticket</th>
                  <th>Price per Ticket</th>
				  <th>Mode of Ticket</th>
                  <th>Promoter Name</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->