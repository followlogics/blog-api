<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Codticket Admin | Login</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/dist/css/AdminLTE.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/iCheck/square/blue.css">
  <script src="<?php echo base_url()?>assets/plugins/jQuery/jquery-2.2.3.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery_validation/jquery.validate.js"></script>
  <script type="text/javascript">
        
        $(document).ready(function() {
            $("#adminlogin").removeAttr("novalidate");
            $("#adminlogin").validate({
               rules: {
                    password: "required",
                    email: {
                      required: true,
                      email: true
                    }
                  },
                messages: {
                    email: "Please enter your email",
                    email: {
                      required: "Please enter your email",
                      email: "Your email address must be in the format of name@domain.com"
                    },
                    password: "Please enter your password",
                }

             });
        });

</script>
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="index.html"><b>Cod</b>Ticket</a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign in to start your session</p>
     <?php    $message = $this->session->flashdata('item');
                        ?>
                          <div class="<?php echo $message['class']?>">
                          <?php echo $message['message']; ?>             
                          </div>

    <!-- <form action="index.html" method="post"> -->
       <?php 
                        $attributes = array('class' => 'form-horizontal','id'=> 'adminlogin');
                                echo form_open('admin/do_signin', $attributes);
        ?>
      <div class="form-group has-feedback">
        <input type="email" class="form-control" placeholder="Email" name="email">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="Password" name="password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat" name="actionlog" value="submit">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>



    <a href="#">I forgot my password</a><br>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 2.2.3 -->

<!-- Bootstrap 3.3.6 -->


<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?php echo base_url()?>assets/plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
<style type="text/css">
    .error{
    color: red;
    padding-top: 5px;
}
.errormsg{color: red;
    padding-bottom: 5px;
    font-size: 16px;}
</style>
</body>
</html>
