<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Manage Event</h1>
      <ol class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Manage Event</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title" style="margin: 8px 0px;">Event Listing</h3>
			  <a href="event-add.html"><button style="float: right" type="button" class="btn btn-primary">Add Event</button></a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped table-responsive">
                <thead>
                <tr>
                  <th>Event Id</th>
				  <th>Event Name</th>
				  <th>Event Type</th>
                  <th>Event Date</th>
                  <th>Event Location</th>
                  <th>Organiser Name</th>
				  <th>Event Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php  $query = $this->db->get('events');
                        $i ='1';
                        foreach ($query->result_array() as $row)
                          {  ?>

                <tr>
                  <td><?php echo $i; ?></td>
				  <td><a href="<?php echo base_url()?>index.php/admin/eventView"><?php echo $row['event_title'];?></a></td>
                  <td><?php echo $row['event_type'] == 'Other' ? $row['otherEventType'] : $row['event_type'];?></td>
				  <td><?php $str =$row['event_startdate'] ;echo  $str=substr($str, 0, strrpos($str, ' '));?></td>
                  <td><?php echo $row['event_location']?></td>
                  <td><?php echo $row['event_organiser_name']?></td>
				  <td><?php echo $row['event_status']?></td>
                  <td><a href="<?php echo base_url()?>index.php/admin/eventView/<?php echo $row['event_id']?>"><button type="button" class="btn btn-success action-btn" title="View More"><i class="fa fa-eye"></i></button></a>
				  <a href="<?php echo base_url()?>index.php/admin/eventEdit"><button type="button" class="btn btn-warning action-btn" title="Edit"><i class="fa fa-pencil-square-o"></i></button></a>
				  <a href="#delete"><button type="button" class="btn btn-danger action-btn" title="Delete"><i class="fa fa-trash-o"></i></button></a></td>
                </tr>
                <?php    $i++;  } ?>  
                                 
                          
                </tbody>
                
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->