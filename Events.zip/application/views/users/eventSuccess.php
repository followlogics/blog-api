<div class="container-fluid header-1">
<div class="header-content">
<h1>Event Live</h1>
<h3><a href="index.html">Home</a> > Event Live</h3>
</div>
</div>
	<?php $event_id = $this->uri->segment(3, 0); ?>
	<div class="container space-top border-rj">
	<div class="row">
    <div class="col-md-10 col-md-offset-1 thanku" style="text-align:center;">
	<h1>Event Live Successfully</h1>
	<h4>Your Event has been successfully Live on Website.</h4>
	<h4>Create Ticket for this Event click here!!!</h4>
	<a href="<?php echo base_url()?>index.php/user/createTicket/<?php echo $event_id?>"><button type="button" class="btn btn-outline-primary-rj">Create Ticket</button></a>
	</div>
    </div>	
	</div>