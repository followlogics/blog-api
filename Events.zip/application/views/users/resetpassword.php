<?php $email = $_GET['email']; ?>
<div class="container"> 
<div id="forgetbox" style="margin-top:95px;" class="mainbox col-md-4 col-md-offset-4 col-sm-8 col-sm-offset-2">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="panel-title">Enter your New password.</div>
                            <div style="float:right; font-size: 85%; position: relative; top:-19px"></div>
                        </div>  
                        <div class="panel-body" >
						
                            <!-- <form id="changepassForm" class="form-horizontal" role="form"> -->
                            <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'changepassForm');
                                echo form_open('user/passwordUpdate', $attributes);
                            ?>
                                
                                <div id="forgetalert" style="display:none" class="alert alert-danger">
                                    <p>Error:</p>
                                    <span></span>
                                </div>
                                 
                                <div class="form-group">
                                    <div class="col-md-12 col-pad">
                                        <label for="password">New Password</label>
                                        <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                                        <?php echo form_error('password');?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12 col-pad">
                                        <label for="confirmpasswd">Confirm Password</label>
                                        <input type="password" class="form-control" name="confirmpasswd" id="confirmpasswd" placeholder="Confirm Password">
                                        <?php echo form_error('confirmpasswd');?>
                                    </div>
                                </div>
                                <input type="hidden" name="email" value="<?php echo $email?>">
                                <div class="form-group">
                                    <!-- Button -->                                        
                                    <div class="col-md-12 col-pad">
                                        <button id="btn-changPass" type="submit" class="btn-new btn-info"><i class="icon-hand-right"></i> &nbsp Reset Password</button>
                                    </div>
                                </div>
                            </form>
                         </div>
                    </div>
         </div> 
		 
    </div>
    <script type="text/javascript">
        
        $(document).ready(function() {
            $("#changepassForm").removeAttr("novalidate");
            $("#changepassForm").validate({
               rules: {
                    password: "required",
                    confirmpasswd: {
                      equalTo: "#password",
                      required: true
                    }
                  },
                messages: {
                    password: "Please enter your new password",
                    confirmpasswd: {
                      required: "Please specify your confirm password",
                      equalTo: "Your confirm password not match"
                    }
                }


             });
        });

</script>