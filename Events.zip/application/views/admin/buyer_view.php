    <?php $buyer_id = $this->uri->segment(3, 0);

                $query = $this->db->get_where('users', array('user_id' => $buyer_id));
                $result = $query->result();
    ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1><?php echo $result[0]->first_name.' '.$result[0]->last_name ?> </h1>
      <ol class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">View Buyer</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url()?>assets/dist/img/user2-160x160.jpg" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo $result[0]->first_name.' '.$result[0]->last_name ?></h3>

              <p class="text-muted text-center"><?php echo $result[0]->email ?></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Name</b> <a class="pull-right"><?php echo $result[0]->first_name.' '.$result[0]->last_name ?></a>
                </li>
                <li class="list-group-item">
                  <b>Phone No.</b> <a class="pull-right"><?php echo $result[0]->phone_number ?></a>
                </li>
                <li class="list-group-item">
                  <b>Email</b> <a class="pull-right"><?php echo $result[0]->email ?></a>
                </li>
              </ul>

              <a href="<?php echo base_url()?>index.php/admin/buyers" class="btn btn-primary btn-block"><b>Back</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          
        </div>
        <!-- /.col -->
        <div class="col-md-9">
		
		<!-- About Me Box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">About Me</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> Personal Information</strong>
				</br></br>
              <p class="text-muted"><b>Name : </b> <?php echo $result[0]->first_name.' '.$result[0]->last_name ?></p>
			  <p class="text-muted"><b>Phone Number : </b><?php echo $result[0]->phone_number ?></p>
			  <p class="text-muted"><b>Email : </b> <?php echo $result[0]->email ?></p>
			  <p class="text-muted"><b>Gender : </b><?php echo $result[0]->gender ?></p>
			  <p class="text-muted"><b>Date of Birth : </b> <?php echo $result[0]->date_of_birth ?></p>

              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
					</br></br>
              <p class="text-muted"><b>Home Address : </b> <?php echo $result[0]->home_address ?></p>
			  <p class="text-muted"><b>Office Address : </b> <?php echo $result[0]->office_address ?> </p>
			  
              <a href="<?php echo base_url()?>index.php/admin/buyerEdit/<?php echo $result[0]->user_id ?>" class="btn btn-primary"><b>Edit Details</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
		
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->