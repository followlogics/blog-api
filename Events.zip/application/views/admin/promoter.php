<?php 
if($this->session->flashdata('message')!=null){  ?>
<script>
 var msg = "<?php echo $this->session->flashdata('message');?>";
toastr.success(msg);
</script>
<?php } ?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Promoters</h1>
      <ol class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Promoters</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title" style="margin: 8px 0px;">Promoters Listing</h3>
			  <a href="<?php echo base_url()?>index.php/admin/addpromoters"><button style="float: right" type="button" class="btn btn-primary">Add Promoters</button></a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped table-responsive">
                <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone No.</th>
                  <th>Gender</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                $this -> db -> select('*');
                $this -> db -> where(' user_role', 'promoter');
                $this -> db -> from('users');
                $query = $this->db->get();
                $result = $query->result();
                foreach($result as $row){ ?>
                <tr>
                  <td><?php echo $row->first_name ?></td>
                  <td><?php echo $row->email ?></td>
                  <td><?php echo $row->phone_number ?></td>
                  <td><?php echo $row->gender ?></td>
                  <td><a href="<?php echo base_url()?>index.php/admin/PromoterView/<?php echo $row->user_id ?>"><button type="button" class="btn btn-success action-btn" title="View More"><i class="fa fa-eye"></i></button></a>
				  <a href="<?php echo base_url()?>index.php/admin/PromoterEdit/<?php echo $row->user_id ?>"><button type="button" class="btn btn-warning action-btn" title="Edit"><i class="fa fa-pencil-square-o"></i></button></a>
				  <a href="<?php echo base_url()?>index.php/admin/promoterdelet/<?php echo $row->user_id ?>"><button type="button" class="btn btn-danger action-btn" title="Delete"><i class="fa fa-trash-o"></i></button></a></td>
                </tr> 
                <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone No.</th>
                  <th>Gender</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
