<?php $admin_id = $this->session->userdata('user_id');

                $query = $this->db->get_where('users', array('user_id' => $admin_id));
                $result = $query->result();
    ?>
    <?php 
if($this->session->flashdata('message')!=null){  ?>
<script>
 var msg = "<?php echo $this->session->flashdata('message');?>";
toastr.success(msg);
</script>
<?php } ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit Profile</h1>
      <ol class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit profile</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-12">

          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Update Your Profile</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <!-- <form class="form-horizontal"> -->
            <?php 
                                $attributes = array('class' => 'form-horizontal');
                                echo form_open('admin/adminprofileEdit', $attributes);
                            ?>
              <div class="box-body">
                <div class="form-group">
                  <label for="firstname" class="col-sm-2 control-label">First Name</label>
                  <div class="col-sm-10">
                    <input type="name" class="form-control" id="firstname" placeholder="First Name" value="<?php echo $result[0]->first_name?>" name="firstname">
                  </div>
                </div>
				<div class="form-group">
                  <label for="lastname" class="col-sm-2 control-label">Last Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="lastname" placeholder="Last Name" value="<?php echo $result[0]->last_name?>" name="lastname">
                  </div>
                </div>
				<div class="form-group">
                  <label for="gender" class="col-sm-2 control-label">Gender</label>
                  <div class="col-sm-10">
                  <select class="form-control">
                    <option value=""  name="gender">Selct Gender</option>
                    <option value="Male" <?php if($result[0]->gender =="Male") echo 'selected="selected"'; ?>>Male</option>
                    <option value="Female" <?php if($result[0]->gender =="Female") echo 'selected="selected"'; ?>>Female</option>
                  </select>
                  </div>
                </div>
				      <div class="form-group">
                  <label for="designation" class="col-sm-2 control-label">Designation</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="designation" placeholder="Designation" value="<?php echo $result[0]->user_role ?>" name="userrole">
                  </div>
                </div>
				      <div class="form-group">
                  <label for="email" class="col-sm-2 control-label">Email</label>
                  <div class="col-sm-10">
                    <input type="email" class="form-control" id="email" placeholder="Email" value="<?php echo $result[0]->email?>" name="email">
                  </div>
                </div>
                <div class="form-group">
                  <label for="designation" class="col-sm-2 control-label">Phone Number</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="designation" placeholder="Designation" value="<?php echo $result[0]->phone_number ?>" name="phonenumber">
                  </div>
                </div>
                <div class="form-group">
                  <label for="address" class="col-sm-2 control-label">Address</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" rows="3" placeholder="Enter Address" name="homeadd"><?php echo $result[0]->home_address?></textarea>
                  </div>
                </div>
				<!-- <div class="form-group">
                  <label for="city" class="col-sm-2 control-label">City</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="city" placeholder="City" value="<?php echo $result[0]->home_address?>">
                  </div>
                </div>
				<div class="form-group">
                  <label for="zip" class="col-sm-2 control-label">Zip</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="zip" placeholder="Zip">
                  </div>
                </div>
				<div class="form-group">
                  <label for="state" class="col-sm-2 control-label">State</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="state" placeholder="State">
                  </div>
                </div>
				<div class="form-group">
                  <label for="country" class="col-sm-2 control-label">Country</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="country" placeholder="Country">
                  </div>
                </div> 
                <div class="form-group">
                  <div class="col-sm-offset-2 col-sm-10">
                    <div class="checkbox">
                      <label>
                        <input type="checkbox"> Remember me
                      </label>
                    </div>
                  </div>
                </div>-->
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-default">Reset</button>
                <button type="submit" class="btn btn-info pull-right" name="editprofil" value="submit">Update</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div> 
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->