<div class="container-fluid header-1">
<div class="header-content">
<h1>Our Solution</h1>
<h3><a href="index.html">Home</a> > Our Solution</h3>
</div>
</div>
	
	<div class="container space-top">
	<div class="row">
    <div class="col-md-6">
	<img src="<?php echo base_url()?>assets/images/solution.jpg">
	</div>
    <div class="col-md-6">
	<div class="event">
	<h1>Our Solution</h1>
	<p></p>
	</div>
	<div class="event-block">
	<p><b>CodTicket ™</b>   is a ticketing company that aims to securely produce and validate tickets for sports, recreational or other activities requiring authentication at the entrance of the public. </p>	
	<p>The objective is to facilitate access to secure tickets for producers and organizers of sporting events, shows or other events.</p>	
	<p>Our activities are characterized by the production of banknotes with unique codes, the supply of equipment allowing the validation of banknotes and the real time monitoring of the process of filling the room. They respond equally well to the needs of clients in low-income countries.</p>	
	</div>
	</div>
    </div>	
	</div>