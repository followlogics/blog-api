<div class="container-fluid header-1">
<div class="header-content">
<h1>Discovery Event</h1>
<h3><a href="index.html">Home</a> > Discovery Event</h3>
</div>
</div>
	
	<div class="container space-top border-rj" style="padding-bottom: 0;">
	<div class="row">
    <div class="col-md-4">
	<div class="event">
	<h1 style='font-size: 23px;margin-bottom: 20px;'>Find An Event</h1>
	<p></p>
	</div>
	<div class="side-list">
	<h4>Time</h4>
	<ul class="list-unstyled">
		<li><a href="#">All</a></li>
		<li><a href="#">Today</a></li>
		<li><a href="#">Tomorrow</a></li>
		<li><a href="#">This Week</a></li>
		<li><a href="#">Next Week</a></li>
		<li><a href="#">This Month</a></li>
		<li><a href="#">Past</a></li>
	</ul>
	</div>
	
	<div class="side-list">
	<h4>Category</h4>
	<ul class="list-unstyled">
		<li><a href="#">All Categories</a></li>
		<li><a href="#">Arts and Entertainment</a></li>
		<li><a href="#">Business and Networking</a></li>
		<li><a href="#">Charities and Non-Profits</a></li>
		<li><a href="#">Education and Student Groups</a></li>
		<li><a href="#">Family or School Reunions</a></li>
		<li><a href="#">Outdoor and Recreational</a></li>
		<li><a href="#">Public Action and Political</a></li>
		<li><a href="#">Social Events and Clubs</a></li>
		<li><a href="#">Religion and Spirituality</a></li>
		<li><a href="#">Sports and Fitness</a></li>
		<li><a href="#">Music</a></li>
		<li><a href="#">Food and Wine</a></li>
		<li><a href="#">Health and Wellness</a></li>
	</ul>
	</div>
	</div>
	
    <div class="col-md-8">
	<div class="row">
						<div id="custom-search-input">
                            <div class="input-group">
                                <input type="text" class="  search-query form-control" placeholder="Search Events" />
                                <span class="input-group-btn">
                                    <button class="btn btn-danger" type="button">
                                        <span class=" glyphicon glyphicon-search"></span>
                                    </button>
                                </span>
                            </div>
                        </div>
						</div>
						
	<div class="row event-area">
    <div class="col-md-4">
	<img src="<?php echo base_url()?>assets/images/event-detail.jpg">
	<h3 class="img-caption">Arts and Entertainment</h3>
	</div>
    <div class="col-md-8">
	<div class="event-detial">
	<h1>Spiritual adventure 2017 <strong>$150</strong></h1>
	<p><span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span></p>
	</div>
	<div class="event-detial-block">
	<p>We take care of creating and validating tickets on the day of the show. Our ticketing system is computerized, innovative and safe.</p>
	<p><span><i class="fa fa-map-marker" aria-hidden="true"></i><span> &nbsp;  505 N Lincoln Ave, Chicago, IL 60653, USA</p>
	<p><span><i class="fa fa-clock-o" aria-hidden="true"></i><span> &nbsp;  MONDAY, MARCH 6TH, 2017, 9:00 am – 4:00 pm</p>		
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i><span> &nbsp; General Ticket  <b>$100</b>  &nbsp; VIP Ticket  <b>$150</b></p>	
	</div>	
	<a href="buy-ticket.html"><button type="button" class="btn btn-outline-primary-5">Buy Ticket</button></a> &nbsp;  
	<a href="event-detail.html"><button type="button" class="btn btn-outline-primary-5">View More</button></a>
	</div>
	</div>
	
	<div class="row event-area">
    <div class="col-md-4">
	<img src="<?php echo base_url()?>assets/images/event-detail.jpg">
	<h3 class="img-caption">Arts and Entertainment</h3>
	</div>
    <div class="col-md-8">
	<div class="event-detial">
	<h1>Spiritual adventure 2017 <strong>$150</strong></h1>
	<p><span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span></p>
	</div>
	<div class="event-detial-block">
	<p>We take care of creating and validating tickets on the day of the show. Our ticketing system is computerized, innovative and safe.</p>
	<p><span><i class="fa fa-map-marker" aria-hidden="true"></i><span> &nbsp;  505 N Lincoln Ave, Chicago, IL 60653, USA</p>
	<p><span><i class="fa fa-clock-o" aria-hidden="true"></i><span> &nbsp;  MONDAY, MARCH 6TH, 2017, 9:00 am – 4:00 pm</p>		
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i><span> &nbsp;  General Ticket  <b>$100</b>  &nbsp; VIP Ticket  <b>$150</b></p>	
	</div>	
	<a href="buy-ticket.html"><button type="button" class="btn btn-outline-primary-5">Buy Ticket</button></a> &nbsp;  
	<a href="event-detail.html"><button type="button" class="btn btn-outline-primary-5">View More</button></a>
	</div>
	</div>
	
	<div class="row event-area">
    <div class="col-md-4">
	<img src="<?php echo base_url()?>assets/images/event-detail.jpg">
	<h3 class="img-caption">Arts and Entertainment</h3>
	</div>
    <div class="col-md-8">
	<div class="event-detial">
	<h1>Spiritual adventure 2017 <strong>$150</strong></h1>
	<p><span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span></p>
	</div>
	<div class="event-detial-block">
	<p>We take care of creating and validating tickets on the day of the show. Our ticketing system is computerized, innovative and safe.</p>
	<p><span><i class="fa fa-map-marker" aria-hidden="true"></i><span> &nbsp;  505 N Lincoln Ave, Chicago, IL 60653, USA</p>
	<p><span><i class="fa fa-clock-o" aria-hidden="true"></i><span> &nbsp;  MONDAY, MARCH 6TH, 2017, 9:00 am – 4:00 pm</p>		
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i><span> &nbsp;  General Ticket  <b>$100</b>  &nbsp; VIP Ticket  <b>$150</b></p>	
	</div>	
	<a href="buy-ticket.html"><button type="button" class="btn btn-outline-primary-5">Buy Ticket</button></a> &nbsp;  
	<a href="event-detail.html"><button type="button" class="btn btn-outline-primary-5">View More</button></a>
	</div>
	</div>
	
	<div class="row event-area">
    <div class="col-md-4">
	<img src="<?php echo base_url()?>assets/images/event-detail.jpg">
	<h3 class="img-caption">Arts and Entertainment</h3>
	</div>
    <div class="col-md-8">
	<div class="event-detial">
	<h1>Spiritual adventure 2017 <strong>$150</strong></h1>
	<p><span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span></p>
	</div>
	<div class="event-detial-block">
	<p>We take care of creating and validating tickets on the day of the show. Our ticketing system is computerized, innovative and safe.</p>
	<p><span><i class="fa fa-map-marker" aria-hidden="true"></i><span> &nbsp;  505 N Lincoln Ave, Chicago, IL 60653, USA</p>
	<p><span><i class="fa fa-clock-o" aria-hidden="true"></i><span> &nbsp;  MONDAY, MARCH 6TH, 2017, 9:00 am – 4:00 pm</p>		
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i><span> &nbsp;  General Ticket  <b>$100</b>  &nbsp; VIP Ticket  <b>$150</b></p>	
	</div>	
	<a href="buy-ticket.html"><button type="button" class="btn btn-outline-primary-5">Buy Ticket</button></a> &nbsp;  
	<a href="event-detail.html"><button type="button" class="btn btn-outline-primary-5">View More</button></a>
	</div>
	</div>
	
	<div class="row event-area">
    <div class="col-md-4">
	<img src="<?php echo base_url()?>assets/images/event-detail.jpg">
	<h3 class="img-caption">Arts and Entertainment</h3>
	</div>
    <div class="col-md-8">
	<div class="event-detial">
	<h1>Spiritual adventure 2017 <strong>$150</strong></h1>
	<p><span><i class="fa fa-heart" aria-hidden="true"></i> 425 Likes<span></p>
	</div>
	<div class="event-detial-block">
	<p>We take care of creating and validating tickets on the day of the show. Our ticketing system is computerized, innovative and safe.</p>
	<p><span><i class="fa fa-map-marker" aria-hidden="true"></i><span> &nbsp;  505 N Lincoln Ave, Chicago, IL 60653, USA</p>
	<p><span><i class="fa fa-clock-o" aria-hidden="true"></i><span> &nbsp;  MONDAY, MARCH 6TH, 2017, 9:00 am – 4:00 pm</p>		
	<p><span><i class="fa fa-ticket" aria-hidden="true"></i><span> &nbsp;  General Ticket  <b>$100</b>  &nbsp; VIP Ticket  <b>$150</b></p>	
	</div>	
	<a href="buy-ticket.html"><button type="button" class="btn btn-outline-primary-5">Buy Ticket</button></a> &nbsp;  
	<a href="event-detail.html"><button type="button" class="btn btn-outline-primary-5">View More</button></a>
	</div>
	</div>
	
	<nav aria-label="Page navigation" class="pagination-block">
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">Next</a></li>
  </ul>
	</nav>
	
	</div>
    </div>	
	</div>
	