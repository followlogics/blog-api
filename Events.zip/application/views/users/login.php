<div class="container">    
        <div id="loginbox" style="margin-top:95px;" class="mainbox col-md-4 col-md-offset-4 col-sm-8 col-sm-offset-2">                    
            <div class="panel panel-info" >
                    <div class="panel-heading">
                        <div class="panel-title">Sign In</div>
                        <div style="float:right; font-size: 80%; position: relative; top:-19px"><a href="<?php echo base_url()?>index.php/user/forget" style="color:#fff">Forgot password?</a></div>
                    </div>     

                    <div style="padding-top:30px" class="panel-body" >

                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
                    
                    
                          <?php    $message = $this->session->flashdata('item');
                        ?>
                          <div class="<?php echo $message['class']?>">
                          <?php echo $message['message']; ?>             
                          </div>                  
                            
                        <!-- <form id="loginform" class="form-horizontal" role="form"> -->
                        <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'loginform');
                                echo form_open('user/do_login', $attributes);
                            ?>
                                    
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input id="login-username" type="text" class="form-control" name="username" value="" placeholder="username or email">
                                        <?php echo form_error('username');?>                                        
                                    </div>
                                
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input id="login-password" type="password" class="form-control" name="password" placeholder="password">
                                        <?php echo form_error('password');?>
                                    </div>
                                    

                                
                            <div class="input-group">
                                      <div class="checkbox">
                                        <label>
                                          <input id="login-remember" type="checkbox" name="remember" value="1"> Remember me
                                        </label>
                                      </div>
                                    </div>


                                <div style="margin-top:10px" class="form-group">
                                   

                                    <div class="col-sm-12 controls">
                                      <!-- <a id="btn-login" href="#" class="btn-new btn-success">Login  </a> -->
                                      <!-- <a id="btn-fblogin" href="#" class="btn-new btn-primary">Login with Facebook</a> -->
                                      <button id="btn-login" type="submit" class="btn-new btn-info" name="loginbt" value="submit"><i class="icon-hand-right"></i> &nbsp Login</button>

                                    </div>
                                </div>


                                <div class="form-group">
                                    <div class="col-md-12 control">
                                        <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
                                            Don't have an account! 
                                        <a href="<?php echo base_url()?>index.php/user/do_signup">
                                            Sign Up Here
                                        </a>
                                        </div>
                                    </div>
                                </div>    
                            </form>     



                        </div>                     
                    </div>  
        </div>
    </div>


    <script type="text/javascript">
        
        $(document).ready(function() {
            $("#loginform").removeAttr("novalidate");
            $("#loginform").validate({
               rules: {
                    username: "required",
                    password: "required",
                  },
                messages: {
                    username: "Please enter your user name",
                    password: "Please enter your password",
                }

             });
        });

</script>